"""Q4 - Building long text: += vs join() vs f-string lines."""
import time
import io

items = [f"Item{i}:Rs{i % 50}" for i in range(200_000)]


def build_plus(parts):
    text = ""
    for p in parts:
        text += p + ";"
    return text


def build_join(parts):
    # TODO 1 completed
    return ";".join(parts) + ";"


def build_fstring_join(parts):
    """(c) one f-string per line, collected in a list, joined once."""
    lines = [f"{p};" for p in parts]
    return "".join(lines)


def build_stringio(parts):
    """Alternative: io.StringIO buffer."""
    buf = io.StringIO()
    for p in parts:
        buf.write(p)
        buf.write(";")
    return buf.getvalue()


def timed(fn, data):
    t = time.perf_counter()
    out = fn(data)
    return out, time.perf_counter() - t


if __name__ == "__main__":
    start = time.perf_counter(); a = build_plus(items); t_plus = time.perf_counter() - start
    start = time.perf_counter(); b = build_join(items); t_join = time.perf_counter() - start
    print("same text:", a == b, "| length:", len(b))
    print(f"+= time: {t_plus:.4f} s   join time: {t_join:.4f} s")

    print("\nThree runs per method (seconds); average of 3")
    methods = [("+=", build_plus), ("list+join", build_join),
               ("f-string+join", build_fstring_join), ("StringIO", build_stringio)]
    for n in (1_000, 10_000, 200_000):
        data = items[:n]
        ref = build_join(data)
        print(f"\nn = {n:,} lines")
        for name, fn in methods:
            runs = []
            for _ in range(3):
                out, t = timed(fn, data)
                assert out == ref
                runs.append(t)
            print(f"  {name:14} runs = {', '.join(f'{r:.5f}' for r in runs)}   avg = {sum(runs)/3:.5f} s")
