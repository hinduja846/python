from decimal import Decimal, ROUND_HALF_UP
BASE = Decimal("30.00")
def steps(value, standard):
    """Return nearest 0.1 percentage-point step count."""
    return int(((value-standard)/Decimal("0.1")).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
def rate_per_litre(fat, snf):
    """Calculate and return rate per litre."""
    return BASE + Decimal(steps(fat,Decimal("3.5")))*Decimal("0.40") + Decimal(steps(snf,Decimal("8.5")))*Decimal("0.30")
def payout(litres, fat, snf):
    """Calculate and return entry payment."""
    return (litres*rate_per_litre(fat,snf)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
print("Rate:", rate_per_litre(Decimal("4.2"),Decimal("8.7")))
print("Payment:", payout(Decimal("8.5"),Decimal("4.2"),Decimal("8.7")))
