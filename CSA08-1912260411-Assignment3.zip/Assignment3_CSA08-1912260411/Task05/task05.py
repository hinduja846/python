"""Q5 - Cleaning cold-storage temperature sensor readings."""
import random, sys, timeit

def loop_clean(readings):
    valid = []
    for c in readings:
        if -50 <= c <= 50:
            valid.append(c)
    fahrenheit = []
    for c in valid:
        fahrenheit.append(c * 9 / 5 + 32)
    return valid, fahrenheit

def comprehension_clean(readings):
    valid = [c for c in readings if -50 <= c <= 50]
    fahrenheit = [c * 9 / 5 + 32 for c in valid]
    return valid, fahrenheit

def map_filter_clean(readings):
    valid = list(filter(lambda c: -50 <= c <= 50, readings))
    fahrenheit = list(map(lambda c: c * 9 / 5 + 32, valid))
    return valid, fahrenheit

if __name__ == "__main__":
    readings = [2.0, 3.5, 9.0, -55.0, 5.0, 51.0, 8.0, 1.0]
    print("Loop result:", loop_clean(readings))
    print("Comprehension result:", comprehension_clean(readings))
    print("map/filter result:", map_filter_clean(readings))
    alarms = [(minute, temp) for minute, temp in enumerate(readings, start=1)
              if not 2 <= temp <= 8]
    print("Alarm minutes (1-based):", [m for m, _ in alarms])
    print("Alarm details:", alarms)
    print("All valid:", comprehension_clean([2, 4, 8])[0])
    print("All invalid:", comprehension_clean([51, -60])[0])
    print("List comprehension size:", sys.getsizeof([x for x in range(1000)]))
    gen = (x for x in range(1000))
    print("Generator expression size:", sys.getsizeof(gen))
    print("\\nTiming (seconds, one run)")
    for n in (10000, 100000, 1000000):
        data = [random.uniform(-60, 60) for _ in range(n)]
        a = timeit.timeit(lambda: loop_clean(data), number=1)
        b = timeit.timeit(lambda: comprehension_clean(data), number=1)
        c = timeit.timeit(lambda: map_filter_clean(data), number=1)
        print(f"n={n:7d}: loop={a:.5f}s comprehension={b:.5f}s map/filter={c:.5f}s")
    assert loop_clean(readings) == comprehension_clean(readings) == map_filter_clean(readings)
