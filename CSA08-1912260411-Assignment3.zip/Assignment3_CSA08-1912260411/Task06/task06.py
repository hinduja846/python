"""Q6 - Nested railway timetable and station index."""
import random, timeit

TIMETABLE = {
 "12601": {"name":"Chennai Mail", "stops":[("Chennai Central","06:00","06:10"),("Arakkonam","07:20","07:22"),("Katpadi","08:30","08:35")], "days":{"Mon","Tue","Wed","Thu","Fri","Sat","Sun"}},
 "12602": {"name":"Kaveri Express", "stops":[("Chennai Central","07:00","07:15"),("Tambaram","07:35","07:37"),("Villupuram","09:20","09:25")], "days":{"Mon","Tue","Wed","Thu","Fri","Sat","Sun"}},
 "12603": {"name":"Nilgiri Express", "stops":[("Chennai Central","21:00","21:15"),("Katpadi","23:20","23:25"),("Jolarpettai","01:10","01:15")], "days":{"Mon","Wed","Fri","Sun"}},
 "12604": {"name":"Pandian Express", "stops":[("Chennai Egmore","20:00","20:10"),("Tambaram","20:30","20:32"),("Villupuram","22:10","22:15")], "days":{"Tue","Thu","Sat"}},
 "12605": {"name":"Vaigai Express", "stops":[("Chennai Egmore","13:00","13:10"),("Tambaram","13:30","13:32"),("Villupuram","15:00","15:05")], "days":{"Mon","Tue","Wed","Thu","Fri","Sat","Sun"}},
}

def station_query(data, station, day):
    found = []
    for number, info in data.items():
        if day in info["days"]:
            for name, arrival, departure in info["stops"]:
                if name == station:
                    found.append((departure, number, info["name"]))
    return sorted(found, key=lambda x: x[0])

def build_index(data):
    index = {}
    for number, info in data.items():
        for station, arrival, departure in info["stops"]:
            index.setdefault(station, []).append((number, info["name"], arrival, departure, info["days"]))
    return index

def indexed_query(index, station, day):
    return sorted([(dep, no, name) for no, name, arr, dep, days in index.get(station, [])
                   if day in days], key=lambda x: x[0])

if __name__ == "__main__":
    print("Trains stopping at Chennai Central on Monday:")
    print(station_query(TIMETABLE, "Chennai Central", "Mon"))
    print("Unknown station:", station_query(TIMETABLE, "Unknown", "Mon"))
    print("Not running day:", station_query(TIMETABLE, "Chennai Egmore", "Mon")[:0]
          if "Mon" not in TIMETABLE["12604"]["days"] else "Train 12604 runs Monday")
    print("Departure at third station of 12601:", TIMETABLE["12601"]["stops"][2][2])
    print("\\nTimetable:")
    for no, info in TIMETABLE.items():
        print(no, info["name"], "|", ", ".join(f"{s} {a}-{d}" for s,a,d in info["stops"]),
              "|", ",".join(sorted(info["days"])))
    idx = build_index(TIMETABLE)
    print("Index agrees:", station_query(TIMETABLE, "Tambaram", "Tue") ==
          indexed_query(idx, "Tambaram", "Tue"))
    print("\\nStation query timing (seconds / 100 queries)")
    for n in (100, 1000, 10000):
        data = {}
        for i in range(n):
            st = [("Central", "08:00", "08:01"), ("South", "09:00", "09:01"),
                  ("West", "10:00", "10:01")][i % 3]
            data[str(i)] = {"name":f"Train {i}", "stops":[st], "days":{"Mon","Wed"}}
        index = build_index(data)
        a = timeit.timeit(lambda: station_query(data, "Central", "Mon"), number=100)
        b = timeit.timeit(lambda: indexed_query(index, "Central", "Mon"), number=100)
        print(f"trains={n:5d}: scan={a:.5f}s indexed={b:.5f}s index_stations={len(index)}")
