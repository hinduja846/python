"""Q3 - Kisan Call Centre complaint word and district analysis."""
import random, re, timeit
from collections import Counter, defaultdict

CALLS = [
    ("North", "seeds not received seeds delayed", "rice"),
    ("South", "fertiliser price high", "wheat"),
    ("North", "seeds price high subsidy not received", "rice"),
]
STOP = {"not", "high", "the", "is", "a", "and"}

def tokens(text):
    return re.findall(r"[a-z]+", text.lower())

def frequencies(texts, stop):
    counts = {}
    for text in texts:
        for word in tokens(text):
            if word not in stop:
                counts[word] = counts.get(word, 0) + 1
    return counts

def top(counts, k):
    return sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:k]

def group_by_district(records):
    groups = defaultdict(list)
    for district, complaint, crop in records:
        groups[district].append(complaint)
    return dict(groups)

def benchmark():
    vocab = ["seed", "water", "crop", "loan", "price", "pest", "fertiliser", "support"]
    for n in (1000, 10000, 100000):
        texts = [" ".join(random.choices(vocab, k=12)) for _ in range(n)]
        words = [w for t in texts for w in tokens(t)]
        distinct = set(words)
        dmethod = timeit.timeit(lambda: frequencies(texts, set()), number=1)
        cmethod = timeit.timeit(lambda: Counter(words), number=1)
        lmethod = timeit.timeit(lambda: [words.count(w) for w in distinct], number=1)
        print(f"n complaints={n:6d}, words={len(words):7d}, distinct={len(distinct):2d}: "
              f"dict={dmethod:.5f}s Counter={cmethod:.5f}s list.count={lmethod:.5f}s")

if __name__ == "__main__":
    print("Top 3 words:", top(frequencies([r[1] for r in CALLS], STOP), 3))
    print("Complaints by district:", group_by_district(CALLS))
    print("Empty text:", frequencies([""], STOP))
    print("Case/punctuation:", frequencies(["SEEDS, seeds! Price."], STOP))
    print("setdefault demo:", (lambda d: (d.setdefault("rice", []).append("water issue"), d))({})[1])
    benchmark()
