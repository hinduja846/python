"""Q4 - Elective registration clash detection using sets."""
import random, timeit

ai_elective = {"192311001", "192311004", "192311007", "192311009"}
iot_elective = {"192311002", "192311004", "192311009", "192311010"}
all_students = {f"1923110{i:02d}" for i in range(1, 11)}

if __name__ == "__main__":
    both = ai_elective & iot_elective
    exactly_one = ai_elective ^ iot_elective
    neither = all_students - (ai_elective | iot_elective)
    print("clash      :", sorted(both))
    print("exactly one:", sorted(exactly_one))
    print("neither    :", sorted(neither))
    # Same results with set methods
    print("Methods agree:", both == ai_elective.intersection(iot_elective)
          and exactly_one == ai_elective.symmetric_difference(iot_elective)
          and neither == all_students.difference(ai_elective.union(iot_elective)))
    print("Duplicate removal:", len(set(["A", "A", "B"])) == 2)
    print("Empty electives:", set() & iot_elective)
    print("Identical electives symmetric difference:", ai_elective ^ ai_elective)

    print("\\nMembership timing (seconds / 1000 checks)")
    for n in (10000, 100000, 1000000):
        values = [str(i) for i in range(n)]
        value_set = set(values)
        target = str(n - 1)
        tl = timeit.timeit(lambda: target in values, number=1000)
        ts = timeit.timeit(lambda: target in value_set, number=1000)
        print(f"n={n:7d}: list={tl:.6f}s set={ts:.6f}s")
    left = list(range(3000)); right = list(range(1500, 4500))
    nested = timeit.timeit(lambda: [x for x in left for y in right if x == y], number=1)
    hashed = timeit.timeit(lambda: set(left) & set(right), number=10) / 10
    print(f"Common values: nested={nested:.5f}s, set intersection={hashed:.5f}s (set build included)")
