"""Q1 - Daily rainfall records: lists, slicing and moving averages."""
import random
import timeit

WINDOW = 7

def weekly_totals(readings):
    return [sum(readings[i:i + 7]) for i in range(0, len(readings), 7)]

def moving_naive(values, window=WINDOW):
    if window <= 0:
        raise ValueError("window must be positive")
    return [sum(values[i:i + window]) / window
            for i in range(len(values) - window + 1)]

def moving_running(values, window=WINDOW):
    if window <= 0:
        raise ValueError("window must be positive")
    if len(values) < window:
        return []
    current = sum(values[:window])
    result = [current / window]
    for i in range(window, len(values)):
        current += values[i] - values[i - window]
        result.append(current / window)
    return result

def dry_days(values):
    return [i + 1 for i, amount in enumerate(values) if amount == 0]

def benchmark():
    print("\\nBenchmark: seconds (naive vs running sum)")
    for n in (365, 36500, 365000):
        data = [random.randint(0, 80) for _ in range(n)]
        loops = 20 if n < 10000 else (3 if n < 100000 else 1)
        a = timeit.timeit(lambda: moving_naive(data), number=loops) / loops
        b = timeit.timeit(lambda: moving_running(data), number=loops) / loops
        windows = max(0, n - 6)
        print(f"n={n:6d}, windows={windows:6d}, naive={a:.6f}s, running={b:.6f}s")

if __name__ == "__main__":
    random.seed(8)
    readings = [random.randint(0, 30) for _ in range(365)]
    weeks = weekly_totals(readings)
    print("First 3 weekly totals:", weeks[:3])
    print("Wettest week (week number, mm):", (weeks.index(max(weeks)) + 1, max(weeks)))
    print("Driest week (week number, mm):", (weeks.index(min(weeks)) + 1, min(weeks)))
    print("Maximum reading (mm, day):", (max(readings), readings.index(max(readings)) + 1))
    print("Minimum reading (mm, day):", (min(readings), readings.index(min(readings)) + 1))
    print("First 5 moving averages:", [round(x, 2) for x in moving_running(readings)[:5]])
    print("Dry days (first 15):", dry_days(readings)[:15])
    print("Slicing: readings[7:14] =", readings[7:14])
    print("Slicing: readings[-7:] =", readings[-7:])
    print("Slicing: readings[::7] =", readings[::7][:10], "... (every seventh reading)")
    print("Empty input:", moving_running([]), "| short input:", moving_running([1, 2, 3]))
    assert moving_naive(readings) == moving_running(readings)
    benchmark()
