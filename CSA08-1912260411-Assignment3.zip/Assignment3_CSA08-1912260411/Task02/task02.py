"""Q2 - Tuples, mutability, aliasing and copying."""
import copy
import sys
import timeit

def make_grid(rows, cols):
    return [[0 for _ in range(cols)] for _ in range(rows)]

if __name__ == "__main__":
    rows, cols = 3, 4
    bad = [[0] * cols] * rows
    bad[0][1] = 7
    good = make_grid(rows, cols)
    good[0][1] = 7
    print("bad :", bad)
    print("good:", good)
    print(bad[0] is bad[1], good[0] is good[1])
    print("bad row ids:", id(bad[0]), id(bad[1]))
    print("good row ids:", id(good[0]), id(good[1]))
    stops = {(13.0827, 80.2707): "Chennai Central",
             (13.0418, 80.2341): "T. Nagar"}
    print(stops[(13.0418, 80.2341)])
    try:
        stops[[13.0418, 80.2341]] = "Invalid key"
    except TypeError as exc:
        print("List key error:", type(exc).__name__, "-", exc)

    original = [[1, 2], [3, 4]]
    alias = original
    shallow_copy = copy.copy(original)
    slice_copy = original[:]
    deep_copy = copy.deepcopy(original)
    original[0][0] = 99
    print("Aliasing sees change:", alias[0][0])
    print("Shallow copy shares inner list:", shallow_copy[0][0])
    print("Slice copy shares inner list:", slice_copy[0][0])
    print("Deep copy is independent:", deep_copy[0][0])
    coordinates = ((13.08, 80.27), (13.04, 80.23))
    for latitude, longitude in coordinates:
        print("Unpacked stop:", latitude, longitude)

    list_million = list(range(1_000_000))
    tuple_million = tuple(range(1_000_000))
    print("Container size for 1,000,000 values (bytes):",
          sys.getsizeof(list_million), sys.getsizeof(tuple_million))
    values = list(range(100_000))
    tuple_values = tuple(values)
    print("Create list (100k):", round(timeit.timeit(lambda: list(values), number=10), 6), "s / 10")
    print("Create tuple (100k):", round(timeit.timeit(lambda: tuple(values), number=10), 6), "s / 10")
    print("Index list:", round(timeit.timeit(lambda: values[50000], number=1000000), 6), "s / 1M")
    print("Index tuple:", round(timeit.timeit(lambda: tuple_values[50000], number=1000000), 6), "s / 1M")
    mixed = ("bus stop", [1, 2, 3])
    mixed[1].append(4)
    print("Mutable list inside tuple:", mixed)
