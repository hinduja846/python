# CSA08-1912260411-Assignment3

- **Name:** V. Hinduja
- **Register number:** 1912260411
- **Course / assignment:** CSA08 - Assignment 3 (CO3: Python data structures)
- **Python version:** Python 3.12 (the programs use standard-library features available in Python 3.10+)
- **Libraries:** Python standard library only (`random`, `timeit`, `sys`, `copy`, `collections`, `re`, `string`, `tracemalloc`, `datetime`).
- **GitHub link:** *(paste the repository URL here and on the report cover page after creating the repository)*

| Folder | Task | Run command | Result |
|---|---|---|---|
| Task01 | Q1 Daily rainfall | `python task01.py` | Weekly totals, extrema, moving averages, dry days and timing comparisons |
| Task02 | Q2 Tuples and copying | `python task02.py` | Shows shared-row bug, independent grid, tuple keys, copying and memory tests |
| Task03 | Q3 Complaint analysis | `python task03.py` | Word counts, district grouping, top-k ranking and dictionary/Counter/list timing |
| Task04 | Q4 Elective sets | `python task04.py` | Clash, exactly-one and neither reports; set/list membership and intersection tests |
| Task05 | Q5 Sensor cleaning | `python task05.py` | Loop, comprehension and map/filter results; alarm minutes and timing/memory tests |
| Task06 | Q6 Railway timetable | `python task06.py` | Five-train nested timetable, station/day queries, sorting and index benchmarks |
| Task07 | Q7 Contact merging | `python task07.py` | Normalises and merges contacts; tests duplicates, missing fields and scaling |

Each task folder contains its Python source, `answer.txt`, `sample_output.txt` and the captured `program_output.txt`. Run each program from its task folder. Timing and memory figures are machine-dependent; the included output is one execution, not a universal benchmark.

## GitHub submission
Create a repository named `CSA08-1912260411-Assignment3`, add these files, and push progressive commits (at least one per task). Add the course faculty as collaborator if the repository is private. Replace the placeholder GitHub URL above after pushing.

Example commands:
```bash
cd Task01
python task01.py
```
