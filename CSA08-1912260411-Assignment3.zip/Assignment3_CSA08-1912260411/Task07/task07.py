"""Q7 - Merge contacts using normalised phone numbers as dictionary keys."""
import random, re, timeit

def normalize_phone(phone):
    if not phone:
        return ""
    digits = re.sub(r"\D", "", phone)
    if digits.startswith("91") and len(digits) == 12:
        digits = digits[2:]
    if digits.startswith("0") and len(digits) == 11:
        digits = digits[1:]
    return digits

def normalize_name(name):
    return " ".join(re.findall(r"[a-z]+", (name or "").lower()))

def merge_contacts(contact_lists):
    merged = {}
    phone_owner = {}
    for source in contact_lists:
        for contact in source:
            phones = {normalize_phone(p) for p in contact.get("phones", [])}
            phones.discard("")
            emails = {e.strip().lower() for e in contact.get("emails", []) if e and e.strip()}
            name = (contact.get("name") or "").strip()
            # A contact without a usable phone cannot safely be merged by phone.
            if not phones:
                key = "no-phone:" + normalize_name(name) + ":" + str(len(merged))
            else:
                existing = [phone_owner[p] for p in phones if p in phone_owner]
                key = existing[0] if existing else sorted(phones)[0]
            if key not in merged:
                merged[key] = {"name": name, "phones": set(), "emails": set(),
                               "name_variants": set()}
            record = merged[key]
            if name:
                record["name_variants"].add(name)
                if not record["name"]:
                    record["name"] = name
            record["phones"].update(phones)
            for phone in phones:
                phone_owner[phone] = key
            record["emails"].update(emails)
    return merged

def benchmark(n):
    contacts = [[{"name":f"Person {i}", "phones":[f"+91 90000 {i:05d}"],
                  "emails":[f"p{i}@example.com"]} for i in range(n)]]
    return timeit.timeit(lambda: merge_contacts(contacts), number=1)

if __name__ == "__main__":
    phone_a = [{"name":"Dr. Ravi", "phones":["+91 98400 12345"], "emails":["RAVI@MAIL.COM"]},
               {"name":"Meena", "phones":["9000011111"], "emails":[]},
               {"name":"No phone record", "phones":[], "emails":["np@mail.com"]}]
    phone_b = [{"name":"ravi kumar", "phones":["9840012345", "09888800000"],
                "emails":["ravi.kumar@mail.com"]},
               {"name":"MEENA", "phones":["+91-90000-11111"], "emails":["meena@mail.com"]},
               {"name":"Arun", "phones":["9888877777"], "emails":[""]}]
    merged = merge_contacts([phone_a, phone_b])
    print("Merged contacts:")
    for key, record in sorted(merged.items()):
        print(key, "=>", record["name"], "| phones:", sorted(record["phones"]),
              "| emails:", sorted(record["emails"]),
              "| name variants:", sorted(record["name_variants"]))
    print("Merged record count:", len(merged))
    print("Hand-check: Ravi has 2 unique numbers and 2 e-mails:",
          len(merged["9840012345"]["phones"]) == 2,
          len(merged["9840012345"]["emails"]) == 2)
    print("\\nScaling time (seconds)")
    for n in (1000, 100000):
        print(f"{n:6d} contacts: {benchmark(n):.5f}s")
