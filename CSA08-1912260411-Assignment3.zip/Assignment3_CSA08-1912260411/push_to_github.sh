#!/bin/sh
# Run from the assignment root after creating the GitHub repository.
git init
git add README.md requirements.txt .gitignore Task01
git commit -m "Complete Assignment 3 Task 1"
git add Task02 && git commit -m "Complete Assignment 3 Task 2"
git add Task03 && git commit -m "Complete Assignment 3 Task 3"
git add Task04 && git commit -m "Complete Assignment 3 Task 4"
git add Task05 && git commit -m "Complete Assignment 3 Task 5"
git add Task06 && git commit -m "Complete Assignment 3 Task 6"
git add Task07 && git commit -m "Complete Assignment 3 Task 7"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
