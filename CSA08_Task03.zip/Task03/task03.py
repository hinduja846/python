"""Q3 - Vehicle registration number validator (string operations only, no regex)."""

def normalise(text):
    """'tn 09 ab 1234' -> 'TN09AB1234' (spaces and hyphens removed, upper case)."""
    # TODO 1 completed
    return text.replace(" ", "").replace("-", "").upper()


def is_valid(reg):
    """Valid form: 2 letters, 2 digits, 1 or 2 letters, 4 digits (e.g. TN09AB1234)."""
    # TODO 2 completed
    if len(reg) not in (9, 10):
        return False
    return (reg[:2].isalpha()          # state code
            and reg[2:4].isdigit()     # district
            and reg[4:-4].isalpha()    # series (1 or 2 letters, length fixed by len check)
            and reg[-4:].isdigit())    # number


def format_reg(reg):
    """'TN09AB1234' -> 'TN 09 AB 1234' (valid numbers only)."""
    if not is_valid(reg):
        raise ValueError("invalid registration number: " + reg)
    return " ".join([reg[:2], reg[2:4], reg[4:-4], reg[-4:]])


if __name__ == "__main__":
    for raw in ["tn 09 ab 1234", "KA-01-M-0007", "TN9AB1234", "TN 22 1234 AB"]:
        reg = normalise(raw)
        print(f"{raw:15} -> {reg:11} {'valid' if is_valid(reg) else 'INVALID'}")

    print("\nReceipt format:")
    for raw in ["tn 09 ab 1234", "KA-01-M-0007", "Tn09Ab1234"]:
        print(f"  {raw!r:18} -> {format_reg(normalise(raw))}")

    # Six designed inputs: prediction written before execution
    tests = [
        ("tn 09 ab 1234",  "TN09AB1234", True),
        ("TN-09-AB-1234",  "TN09AB1234", True),
        ("Tn09Ab1234",     "TN09AB1234", True),
        ("MH-12-A-9999",   "MH12A9999",  True),
        ("TN 09 ABC 1234", "TN09ABC1234", False),   # 3 series letters -> length 11
        ("T1 09 AB 1234",  "T109AB1234", False),    # digit in state code
    ]
    print("\nPredicted vs observed:")
    ok = True
    for raw, pred_norm, pred_valid in tests:
        reg = normalise(raw)
        good = (reg == pred_norm) and (is_valid(reg) == pred_valid)
        ok &= good
        print(f"  {raw:16} norm={reg:12} valid={is_valid(reg)!s:5} predicted={pred_valid!s:5} {'OK' if good else 'MISMATCH'}")
    print("All predictions correct:", ok)

    print("\nImmutability and slicing:")
    text = "tn09ab1234"
    up = text.upper()
    print("  text.upper() ->", up, "| text still ->", text)
    try:
        text[0] = "T"
    except TypeError as e:
        print("  text[0] = 'T' ->", type(e).__name__ + ":", e)
    for s in ("TN09A1234", "TN09AB1234"):
        print(f"  s={s} len={len(s)}  s[-4:]={s[-4:]!r}  s[4:-4]={s[4:-4]!r}")

    # Alternative: regular expression
    import re, timeit
    def is_valid_re(reg):
        return re.fullmatch(r"[A-Z]{2}[0-9]{2}[A-Z]{1,2}[0-9]{4}", reg) is not None
    cases = ["TN09AB1234", "KA01M0007", "TN9AB1234", "TN221234AB", "TN09ABC1234", ""]
    print("\nRegex agrees with slicing on", len(cases), "cases:",
          all(is_valid(c) == is_valid_re(c) for c in cases))
    pat = re.compile(r"[A-Z]{2}[0-9]{2}[A-Z]{1,2}[0-9]{4}")
    n = 200_000
    t_slice = timeit.timeit(lambda: is_valid("TN09AB1234"), number=n) / n * 1e6
    t_re = timeit.timeit(lambda: pat.fullmatch("TN09AB1234"), number=n) / n * 1e6
    print(f"Time per check: slicing {t_slice:.3f} us, precompiled regex {t_re:.3f} us")
    print("Note: str.isalpha()/isdigit() also accept non-ASCII letters/digits, e.g.",
          "'\u0661\u0662'.isdigit() =", "\u0661\u0662".isdigit(),
          "; the regex [A-Z]/[0-9] is ASCII-only.")
