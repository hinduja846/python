from decimal import Decimal, InvalidOperation

def read_decimal(text):
    try:
        value = Decimal(text.strip())
        if not value.is_finite():
            raise InvalidOperation
        return value
    except InvalidOperation:
        return None

for sample in ("8.5", " 8.5 ", "8,5", "eight"):
    print(repr(sample), "->", read_decimal(sample))
amount = Decimal("123.456").quantize(Decimal("0.01"))
print(f"Payment: {amount:8.2f}")
