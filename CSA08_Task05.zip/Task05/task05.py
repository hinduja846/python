"""Q5 - Functions, parameters and scope (canteen order system)."""

def add_item_buggy(item, order=[]):
    order.append(item)
    return order


def add_item(item, order=None):
    # TODO 1 completed
    if order is None:
        order = []
    order.append(item)
    return order


# ---- positional / keyword / default ------------------------------------------
def price_line(item, qty=1, rate=10):
    return f"{item} x{qty} @ Rs{rate} = Rs{qty * rate}"

# ---- returning more than one value ------------------------------------------------
def bill(prices, gst_percent=5):
    total = sum(prices)
    gst = round(total * gst_percent / 100, 2)
    return total, gst, round(total + gst, 2)         # a tuple

# ---- scope: local / global / nonlocal -------------------------------------------
counter = 0                                          # global

def local_demo():
    counter = 100                                    # new LOCAL name
    return counter

def global_demo():
    global counter
    counter += 1                                     # changes the global
    return counter

def nonlocal_demo():
    count = 0
    def inner():
        nonlocal count
        count += 1
        return count
    inner(); inner()
    return count

# ---- alternative: closure ---------------------------------------------------------
def new_order():
    items = []
    def add(item):
        items.append(item)
        return list(items)
    return add


if __name__ == "__main__":
    print(add_item_buggy("Tea"), add_item_buggy("Vada"))
    print(add_item("Tea"), add_item("Vada"))
    print("add_item_buggy.__defaults__ :", add_item_buggy.__defaults__)
    print("add_item.__defaults__       :", add_item.__defaults__)

    print("\nThree customers in sequence (fixed design)")
    c1 = add_item("Tea");   add_item("Vada", c1)
    c2 = add_item("Coffee")
    c3 = add_item("Dosa");  add_item("Juice", c3); add_item("Idli", c3)
    print(" customer 1:", c1); print(" customer 2:", c2); print(" customer 3:", c3)
    print(" independent objects:", c1 is not c2 is not c3, "| ids differ:", len({id(c1), id(c2), id(c3)}) == 3)

    print("\nPositional / keyword / default")
    print(" ", price_line("Tea"))
    print(" ", price_line("Vada", 3))
    print(" ", price_line("Dosa", rate=40, qty=2))

    print("\nMultiple return values")
    total, gst, grand = bill([10, 12, 40])
    print(f"  total={total} gst={gst} grand={grand}   (raw tuple: {bill([10, 12, 40])})")

    print("\nScope")
    print("  local_demo() ->", local_demo(), "| global counter still", counter)
    print("  global_demo() ->", global_demo(), "| global counter now", counter)
    print("  nonlocal_demo() ->", nonlocal_demo())
    def no_global():
        try:
            counter += 1
        except UnboundLocalError as e:
            return "UnboundLocalError: " + str(e)
    print("  without 'global':", no_global())

    print("\nClosure alternative: one add() per customer")
    a, b = new_order(), new_order()
    a("Tea"); a("Vada"); b("Coffee")
    print("  customer A:", a("Idli"), "| customer B:", b("Dosa"))
