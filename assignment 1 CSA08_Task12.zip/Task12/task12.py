"""Season-aware milk payment calculator for Task 12."""
from decimal import Decimal, ROUND_HALF_UP

CENT = Decimal("0.01")
STEP = Decimal("0.1")
STANDARD_FAT = Decimal("3.5")
STANDARD_SNF = Decimal("8.5")
SNF_STEP_VALUE = Decimal("0.30")
VOLUME_THRESHOLD = Decimal("500")
BONUS_PER_LITRE = Decimal("0.50")

RATE_CARDS = {
    "regular": {"base": Decimal("30.00"), "fat_step": Decimal("0.40")},
    "april_june": {"base": Decimal("32.00"), "fat_step": Decimal("0.45")},
}

def money(x):
    """Round a currency amount to paisa using half-up."""
    return x.quantize(CENT, rounding=ROUND_HALF_UP)

def steps(reading, standard):
    """Nearest 0.1 percentage-point step from the standard."""
    return int(((reading-standard)/STEP).quantize(Decimal("1"), rounding=ROUND_HALF_UP))

def get_rate_card(season):
    """Return the rate card for the selected season."""
    if season not in RATE_CARDS:
        raise ValueError("Unknown season")
    return RATE_CARDS[season]

def rate_per_litre(fat, snf, season="regular"):
    """Calculate rate using the selected seasonal rate card."""
    card = get_rate_card(season)
    result = (card["base"] + Decimal(steps(fat, STANDARD_FAT))*card["fat_step"]
              + Decimal(steps(snf, STANDARD_SNF))*SNF_STEP_VALUE)
    return money(result)

def ten_day_payment(entries, season="regular"):
    """Return base total, litres, bonus and final total for valid entries.

    Entries are tuples (litres, fat, snf). This example assumes inputs were
    validated before the function is called.
    """
    base_total = Decimal("0.00")
    total_litres = Decimal("0")
    for litres, fat, snf in entries:
        rate = rate_per_litre(fat, snf, season)
        base_total += money(litres*rate)
        total_litres += litres
    bonus = money(total_litres*BONUS_PER_LITRE) if total_litres > VOLUME_THRESHOLD else Decimal("0.00")
    return money(base_total), total_litres, bonus, money(base_total+bonus)

def run_tests():
    """Verify regular/seasonal rates and the strict >500 litre bonus."""
    f, s = Decimal("4.26"), Decimal("8.70")
    assert rate_per_litre(f, s, "april_june") == Decimal("36.20")
    assert rate_per_litre(f, s, "regular") == Decimal("33.80")
    e510 = [(Decimal("510"), f, s)]
    base, litres, bonus, final = ten_day_payment(e510, "april_june")
    assert bonus == Decimal("255.00")
    e500 = [(Decimal("500"), f, s)]
    _, _, bonus500, _ = ten_day_payment(e500, "april_june")
    assert bonus500 == Decimal("0.00")
    print("Season tests passed")
    print("April-June rate:", rate_per_litre(f,s,"april_june"))
    print("Regular rate:", rate_per_litre(f,s,"regular"))
    print("510 L:", base, "bonus:", bonus, "final:", final)
    print("500 L bonus:", bonus500)

if __name__ == "__main__":
    run_tests()
