"""Attendance statistics."""
def percentage(present, absent):
    total = present + absent
    return present / total * 100 if total else 0.0

def absent_three_days(statuses):
    return len(statuses) >= 3 and all(status == "A" for status in statuses[-3:])
