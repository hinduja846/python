"""Read attendance rows from a text file."""
def read_rows(path):
    with open(path, "r", encoding="utf-8") as source:
        return [line.strip().split(",") for line in source if line.strip()]
