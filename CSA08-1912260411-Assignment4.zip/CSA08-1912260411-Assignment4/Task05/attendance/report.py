"""Write attendance reports."""
def write_percentage(path, rows):
    with open(path, "w", encoding="utf-8") as output:
        output.write("Register,Percentage\\n")
        for reg, pct in rows:
            output.write(f"{reg},{pct:.2f}%\\n")
