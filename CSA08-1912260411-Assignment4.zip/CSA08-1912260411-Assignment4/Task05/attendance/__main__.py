from .stats import percentage, absent_three_days
from .reader import read_rows
def main():
    print("Package percentage:", f"{percentage(3, 1):.2f}%")
    print("Three consecutive absences:", absent_three_days(["P", "A", "A", "A"]))
if __name__ == "__main__":
    main()
