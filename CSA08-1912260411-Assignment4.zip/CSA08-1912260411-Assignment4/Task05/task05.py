"""Task 5: Compare four ways to organise attendance code."""
from pathlib import Path
import subprocess
import sys

def percentage(present, absent):
    total = present + absent
    return (present / total * 100) if total else 0.0

def absent_three_days(statuses):
    """Return True when the last three statuses are all A."""
    return len(statuses) >= 3 and all(x == "A" for x in statuses[-3:])

def main():
    print("Single script percentage:", f"{percentage(3, 1):.2f}%")
    print("Three consecutive absences:", absent_three_days(["P", "A", "A", "A"]))
    print("Four organisation styles are documented in answer.txt.")
    print("Package demo files are in attendance/; run: python -m attendance")

if __name__ == "__main__":
    main()
