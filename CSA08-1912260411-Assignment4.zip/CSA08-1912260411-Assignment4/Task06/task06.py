"""Task 6: College fest registration processor."""
from pathlib import Path
import re

def valid_email(email):
    # Basic validation using string methods; one @, nonempty parts and dotted domain.
    if email.count("@") != 1:
        return False
    local, domain = email.split("@")
    return bool(local and domain and "." in domain and not email.startswith("@")
                and not email.endswith("@") and " " not in email)

def parse_registration(line):
    fields = [part.strip() for part in line.strip().split(",")]
    if len(fields) != 5:
        raise ValueError(f"expected 5 fields, found {len(fields)}")
    reg, name, department, email, event_text = fields
    if not all((reg, name, department, email, event_text)):
        raise ValueError("required field is empty")
    if not valid_email(email):
        raise ValueError(f"invalid email {email!r}")
    events = [event.strip() for event in event_text.split(";") if event.strip()]
    if not events:
        raise ValueError("no valid events supplied")
    return {"reg": reg, "name": name, "department": department,
            "email": email, "events": events}

def process_files(input_dir, output_dir, expected_departments):
    source_dir, out = Path(input_dir), Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    seen = set()
    master = []
    errors = []
    for dept in expected_departments:
        path = source_dir / f"{dept}.txt"
        try:
            with path.open("r", encoding="utf-8") as source:
                for line_no, line in enumerate(source, 1):
                    if not line.strip():
                        continue
                    try:
                        record = parse_registration(line)
                        if record["reg"] in seen:
                            raise ValueError(f"duplicate register number {record['reg']}")
                        seen.add(record["reg"])
                        master.append(record)
                    except ValueError as exc:
                        errors.append(f"{path.name}:{line_no}: {exc}")
        except (FileNotFoundError, PermissionError, UnicodeDecodeError, OSError) as exc:
            errors.append(f"{path.name}: {type(exc).__name__}: {exc}")

    with (out / "master_list.csv").open("w", encoding="utf-8") as master_file:
        master_file.write("Register,Name,Department,Email,Events\n")
        for r in master:
            master_file.write(f'{r["reg"]},{r["name"]},{r["department"]},{r["email"]},"{";".join(r["events"])}"\n')

    event_map = {}
    for record in master:
        for event in record["events"]:
            event_map.setdefault(event, []).append(record)
    for event, participants in event_map.items():
        safe_name = "".join(c if c.isalnum() else "_" for c in event)
        with (out / f"event_{safe_name}.txt").open("w", encoding="utf-8") as event_file:
            for r in participants:
                event_file.write(f'{r["reg"]},{r["name"]},{r["department"]}\n')

    with (out / "summary.txt").open("w", encoding="utf-8") as summary:
        summary.write(f"Valid unique registrations: {len(master)}\n")
        summary.write(f"Events: {len(event_map)}\n")
        for event, participants in sorted(event_map.items()):
            summary.write(f"{event}: {len(participants)} participants\n")
    with (out / "error_log.txt").open("w", encoding="utf-8") as log:
        for error in errors:
            log.write(error + "\n")
    return master, errors

if __name__ == "__main__":
    sample = Path("department_files")
    sample.mkdir(exist_ok=True)
    (sample / "ECE.txt").write_text(
        "191001,Anu,ECE,anu@example.com,Music;Dance\n"
        "191002,Bala,ECE,bala@example.com,Drama\n"
        "191001,Anu,ECE,anu@example.com,Music\n", encoding="utf-8")
    (sample / "CSE.txt").write_text(
        "191003,Charu,CSE,charu.example.com,Music\n"
        "damaged,line\n", encoding="utf-8")
    # MECH.txt is intentionally absent to demonstrate missing-file handling.
    master, errors = process_files(sample, "output", ["ECE", "CSE", "MECH"])
    print("Valid unique registrations:", len(master))
    print("Master:", [r["reg"] for r in master])
    print("Errors:")
    for error in errors:
        print(error)
    print("Created master_list.csv, event lists, summary.txt and error_log.txt")
