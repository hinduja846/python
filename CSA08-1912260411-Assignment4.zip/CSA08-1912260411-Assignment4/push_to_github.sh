#!/bin/sh
# Run after creating the GitHub repository and configuring the remote.
git init
git add README.md requirements.txt .gitignore Task01 Task02 Task03 Task04 Task05 Task06
git commit -m "Add Assignment 4 files and solutions"
# git branch -M main
# git remote add origin https://github.com/USERNAME/CSA08-1912260411-Assignment4.git
# git push -u origin main
