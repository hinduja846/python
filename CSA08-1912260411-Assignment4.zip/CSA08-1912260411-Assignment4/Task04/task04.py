"""Task 4: Demonstrate and repair return-book log handling."""
from pathlib import Path

def buggy_save_returns(books, log_name):
    log = open(log_name, "w", encoding="utf-8")
    for book in books:
        log.write(book)
    log.close()

def repaired_save_returns(books, log_name):
    with open(log_name, "a", encoding="utf-8") as log:
        for book in books:
            log.write(book.rstrip("\n") + "\n")

def process(day_file, log_name, error_log):
    try:
        with open(day_file, "r", encoding="utf-8") as source:
            books = source.read().splitlines()
        repaired_save_returns(books, log_name)
    except (FileNotFoundError, PermissionError, UnicodeDecodeError, OSError) as exc:
        with open(error_log, "a", encoding="utf-8") as errors:
            errors.write(f"{day_file}: {type(exc).__name__}: {exc}\n")

if __name__ == "__main__":
    Path("day1.txt").write_text("Book A\nBook B\n", encoding="utf-8")
    Path("day2.txt").write_text("Book C\n", encoding="utf-8")
    Path("day3.txt").write_text("Book D\n", encoding="utf-8")

    buggy = "buggy_returns.log"
    for day in ("day1.txt", "day2.txt", "day3.txt"):
        with open(day, "r", encoding="utf-8") as f:
            buggy_save_returns(f.read().splitlines(), buggy)
    print("Buggy log (only final day; entries joined):")
    print(repr(Path(buggy).read_text(encoding="utf-8")))

    fixed, errors = "returns.log", "errors.log"
    for name in (fixed, errors):
        Path(name).write_text("", encoding="utf-8")
    for day in ("day1.txt", "day2.txt", "day3.txt", "missing_day.txt"):
        process(day, fixed, errors)
    print("Repaired log:")
    print(Path(fixed).read_text(encoding="utf-8"), end="")
    print("Error log:")
    print(Path(errors).read_text(encoding="utf-8"), end="")
