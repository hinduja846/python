"""Task 3: Specific exception handling for attendance records."""
import os
import tempfile

class InvalidRecord(Exception):
    """Raised when a line is not in the expected attendance format."""

def parse_line(line):
    parts = line.strip().split(",")
    if len(parts) != 3:
        raise InvalidRecord(f"expected 3 fields, found {len(parts)}")
    if parts[2] not in ("P", "A"):
        raise InvalidRecord(f"invalid status {parts[2]!r}")
    if not parts[0] or not parts[1]:
        raise InvalidRecord("register number and date must not be empty")
    return tuple(parts)

def summarise(path):
    present, absent, errors = 0, 0, []
    try:
        with open(path, "r", encoding="utf-8") as file:
            for line_no, line in enumerate(file, 1):
                try:
                    _, _, status = parse_line(line)
                except InvalidRecord as exc:
                    errors.append((line_no, str(exc)))
                else:
                    if status == "P":
                        present += 1
                    else:
                        absent += 1
    except FileNotFoundError as exc:
        raise RuntimeError(f"attendance file not found: {path}") from exc
    except PermissionError as exc:
        raise RuntimeError(f"permission denied: {path}") from exc
    except UnicodeDecodeError as exc:
        raise RuntimeError(f"file is not valid UTF-8: {path}") from exc
    finally:
        # The with statement closes an opened file automatically.
        pass
    return present, absent, errors

if __name__ == "__main__":
    data = ("192311001,2026-10-08,P\n192311002,2026-10-08,A\n"
            "192311003,2026-10-08\n192311004,2026-10-08,L\n")
    with tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False, encoding="utf-8") as tmp:
        tmp.write(data)
        path = tmp.name
    try:
        print(summarise(path))
    finally:
        os.remove(path)
    try:
        summarise("file_that_does_not_exist.csv")
    except RuntimeError as exc:
        print(type(exc.__cause__).__name__, "handled:", exc)
