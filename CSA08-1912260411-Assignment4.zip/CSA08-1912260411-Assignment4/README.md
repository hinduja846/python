# CSA08-1912260411-Assignment4

- **Name:** V. Hinduja
- **Register number:** 1912260411
- **Course:** Python Programming (CSA08)
- **Assignment:** Assignment 4 – CO4 (Files, Exceptions, Modules and Packages)
- **Python version:** 3.12 (compatible with Python 3.10+)
- **Libraries:** Python standard library only
- **GitHub repository link:** *(paste your repository URL here and on the report cover page)*

| Folder | Task | Run command (from that folder) | Result |
|---|---|---|---|
| Task01 | File-processing design review | `python task01.py` | Reads bills line by line, totals valid amounts and records rejected lines |
| Task02 | Biometric attendance processing | `python task02.py` | Calculates attendance percentages, below-75% list and damaged-line log |
| Task03 | Exception handling | `python task03.py` | Completes InvalidRecord parser and demonstrates specific exception handling |
| Task04 | File and exception forensics | `python task04.py` | Demonstrates overwrite/newline defects and repaired append-based logging |
| Task05 | Modules and packages | `python task05.py` | Demonstrates four code organisations and package imports |
| Task06 | College fest registration challenge | `python task06.py` | Builds clean master list, event lists, summary and error log |

Each task folder contains its source code, sample input(s), captured text output and an answer/design note.
All code uses the Python standard library; no third-party packages are required.

## Execution
Run each program from its own folder:
`python task01.py` through `python task06.py`.

## GitHub submission
Create a repository named `CSA08-1912260411-Assignment4`. Add these files and commit each task folder progressively (at least one commit per task). Add the faculty as a collaborator if the repository is private. Paste the working GitHub URL above and on the report cover page.

## Note
The execution output files in this ZIP are text captures produced by running the included programs. Replace or supplement them with screenshots from your own Python environment before final submission if screenshots are specifically required by your faculty.
