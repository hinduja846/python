"""Task 2: Monthly biometric attendance processor."""
from pathlib import Path
from collections import defaultdict

def process_month(folder, output_folder):
    folder = Path(folder)
    out = Path(output_folder)
    out.mkdir(parents=True, exist_ok=True)
    counts = defaultdict(lambda: {"P": 0, "A": 0})
    damaged = []
    daily_files = sorted(folder.glob("*.txt"))

    for path in daily_files:
        try:
            with path.open("r", encoding="utf-8") as source:
                for line_no, raw in enumerate(source, 1):
                    fields = [x.strip() for x in raw.strip().split(",")]
                    if len(fields) != 3 or fields[2] not in ("P", "A") or not fields[0] or not fields[1]:
                        damaged.append((path.name, line_no, raw.rstrip("\n")))
                        continue
                    reg, date, status = fields
                    counts[reg][status] += 1
        except (FileNotFoundError, PermissionError, UnicodeDecodeError) as exc:
            damaged.append((path.name, 0, f"{type(exc).__name__}: {exc}"))

    with (out / "attendance_report.txt").open("w", encoding="utf-8") as report:
        report.write("Register Number,Present,Absent,Percentage\n")
        for reg in sorted(counts):
            p, a = counts[reg]["P"], counts[reg]["A"]
            total = p + a
            pct = (p / total * 100) if total else 0
            report.write(f"{reg},{p},{a},{pct:.2f}%\n")
    with (out / "below_75.txt").open("w", encoding="utf-8") as low:
        for reg in sorted(counts):
            p, a = counts[reg]["P"], counts[reg]["A"]
            total = p + a
            pct = (p / total * 100) if total else 0
            if total and pct < 75:
                low.write(f"{reg},{pct:.2f}%\n")
    with (out / "damaged_lines.txt").open("w", encoding="utf-8") as log:
        for filename, line_no, raw in damaged:
            log.write(f"{filename}:{line_no}: {raw}\n")
    return counts, damaged

if __name__ == "__main__":
    data = Path("daily_files")
    data.mkdir(exist_ok=True)
    (data / "day01.txt").write_text(
        "191001,2026-10-01,P\n191002,2026-10-01,A\nbroken,line\n", encoding="utf-8")
    (data / "day02.txt").write_text(
        "191001,2026-10-02,A\n191002,2026-10-02,P\n", encoding="utf-8")
    counts, damaged = process_month(data, "output")
    print("Attendance counts:", dict(counts))
    print("Damaged:", damaged)
    print("Created output/attendance_report.txt, below_75.txt, damaged_lines.txt")
