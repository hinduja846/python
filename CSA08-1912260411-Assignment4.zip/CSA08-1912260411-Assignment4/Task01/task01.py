"""Task 1: Robust hostel mess-bill processing."""
from decimal import Decimal, InvalidOperation
from pathlib import Path

def process_bills(filename):
    total = Decimal("0.00")
    report = []
    rejected = []
    try:
        with open(filename, "r", encoding="utf-8") as file:
            for line_number, raw_line in enumerate(file, start=1):
                line = raw_line.strip()
                if not line:                 # ignore blank/last empty line
                    continue
                try:
                    parts = [part.strip() for part in line.split(",")]
                    if len(parts) != 3:
                        raise ValueError("expected 3 comma-separated fields")
                    reg_no, name, amount_text = parts
                    if not reg_no or not name:
                        raise ValueError("register number and name are required")
                    amount = Decimal(amount_text)
                    if not amount.is_finite() or amount < 0:
                        raise ValueError("amount must be a non-negative number")
                    total += amount
                    report.append(f"{name} {amount:.2f}")
                except (ValueError, InvalidOperation) as error:
                    rejected.append((line_number, raw_line.rstrip("\n"), str(error)))
    except (FileNotFoundError, PermissionError, UnicodeDecodeError) as error:
        print(f"Cannot process {filename}: {type(error).__name__}: {error}")
        return [], Decimal("0.00"), [(0, str(filename), str(error))]
    return report, total, rejected

if __name__ == "__main__":
    sample = Path("mess_oct.txt")
    if not sample.exists():
        sample.write_text(
            "192311001,Anu,1250.50\n"
            "192311002,Bala,980\n"
            "192311003,Charu,wrong\n"
            "192311004,Deepa,1100.25\n"
            "damaged,line\n", encoding="utf-8")
    report, total, rejected = process_bills(sample)
    print("MESS BILL REPORT")
    print("\n".join(report))
    print("Total", f"{total:.2f}")
    print("Rejected lines:")
    for item in rejected:
        print(item)
