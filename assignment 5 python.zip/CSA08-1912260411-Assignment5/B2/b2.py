"""B2 - Engineer adversarial data."""
import csv, io, os, sqlite3, time
import pandas as pd

# ---------------- Complete the Code ----------------------------------------
readings = [("Adyar", "2026-10-01", 48.0), ("Guindy", "2026-10-01", 95.0),
            ("Guindy", "2026-10-03", 121.0), ("Adyar", "2026-10-04", 60.0)]
con = sqlite3.connect(":memory:")
con.execute("CREATE TABLE aq (station TEXT, day TEXT, pm25 REAL)")
con.executemany("INSERT INTO aq VALUES (?, ?, ?)", readings)    # TODO 1
con.commit()

def station_average(name):
    row = con.execute("SELECT AVG(pm25) FROM aq WHERE station = ?", (name,)).fetchone()   # TODO 2
    return row[0]

print("=== Complete the Code ===")
print(station_average("Adyar"), station_average("Guindy"))
print(station_average("Adyar' OR '1'='1"))      # an injection attempt finds nothing

# ---------------- Adversarial file inputs ----------------------------------
REQUIRED = ["station", "date", "pm25"]
def safe_load(path):
    try:
        raw = open(path, "rb").read()
        if not raw.strip():
            return "REJECTED: empty file"
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError:
            text = raw.decode("latin-1"); note = " (decoded as latin-1 after UTF-8 failed)"
        else:
            note = ""
        head = text.splitlines()[0]
        dialect = csv.Sniffer().sniff(head, delimiters=",;|\t") if ("," in head or ";" in head or "|" in head or "\t" in head) else None
        delim = dialect.delimiter if dialect else ","
        rdr = csv.DictReader(io.StringIO(text), delimiter=delim)
        missing = [c for c in REQUIRED if c not in (rdr.fieldnames or [])]
        if missing:
            return f"REJECTED: missing column(s) {missing}; found {rdr.fieldnames}"
        n = sum(1 for _ in rdr)
        return f"OK: {n} rows, delimiter '{delim}'{note}"
    except Exception as e:
        return f"ERROR {type(e).__name__}: {e}"

os.makedirs("adv", exist_ok=True)
files = {
 "good.csv": "station,date,pm25\nAdyar,2026-10-01,48\n",
 "missing_col.csv": "station,date\nAdyar,2026-10-01\n",
 "semicolon.csv": "station;date;pm25\nAdyar;2026-10-01;48\n",
 "empty.csv": "",
}
for n, t in files.items(): open(f"adv/{n}", "w", encoding="utf-8").write(t)
open("adv/latin1.csv", "wb").write("station,date,pm25\nPerungudi \xe9,2026-10-01,48\n".encode("latin-1"))
print("\n=== Adversarial files: robust loader ===")
for n in ["good.csv", "missing_col.csv", "semicolon.csv", "latin1.csv", "empty.csv"]:
    print(f"{n:16} -> {safe_load('adv/'+n)}")
print("\n--- Naive loader (csv.DictReader with default comma) on the semicolon file ---")
r = list(csv.DictReader(open("adv/semicolon.csv")))
print("fieldnames:", list(r[0].keys()), "-> KeyError on r['pm25']:", end=" ")
try: r[0]["pm25"]
except KeyError as e: print("KeyError", e)
print("--- pandas.read_csv on the empty file ---")
try: pd.read_csv("adv/empty.csv")
except Exception as e: print(type(e).__name__, ":", e)
print("--- latin-1 file read as utf-8 ---")
try: open("adv/latin1.csv", encoding="utf-8").read()
except UnicodeDecodeError as e: print("UnicodeDecodeError:", e.reason)

# ---------------- SQL injection --------------------------------------------
db = sqlite3.connect(":memory:")
db.execute("CREATE TABLE stations (name TEXT, secret TEXT)")
db.executemany("INSERT INTO stations VALUES (?,?)", [("Adyar", "a1"), ("Guindy", "g2"), ("O'Brien Road", "o3")])
def concat(name):
    sql = "SELECT * FROM stations WHERE name = '" + name + "'"
    try: return sql, db.execute(sql).fetchall()
    except sqlite3.Error as e: return sql, f"{type(e).__name__}: {e}"
def param(name): return db.execute("SELECT * FROM stations WHERE name = ?", (name,)).fetchall()
print("\n=== Quote-character search ===")
for s in ["O'Brien Road", "Adyar' OR '1'='1", "x'; DROP TABLE stations; --"]:
    sql, res = concat(s)
    print("\ninput        :", s); print("concatenated :", sql); print("  result     :", res)
    print("placeholder  :", param(s))
print("table still exists:", db.execute("SELECT count(*) FROM stations").fetchone()[0], "rows")
try:
    db.executescript("SELECT 1; DROP TABLE stations; --")
    print("(executescript demo: stacked statement would run; table gone)")
except Exception as e: print(e)
try: db.execute("SELECT count(*) FROM stations")
except sqlite3.Error as e: print("after executescript:", e)

# ---------------- Sentiment adversarial ------------------------------------
POS = {"good", "clean", "fast", "helpful", "improved"}; NEG = {"bad", "dirty", "slow", "rude", "smoke", "broken"}; NEGT = {"not", "never", "no"}
def score(t):
    w = t.lower().replace(".", " ").replace(",", " ").replace("!", " ").split(); tot = 0
    for i, x in enumerate(w):
        v = 1 if x in POS else -1 if x in NEG else 0
        if v and i and w[i-1] in NEGT: v = -v
        tot += v
    return tot
tests = [("Oh great, another smoke-filled day. Wonderful.", "negative", "sarcasm"),
         ("Oh, the air is so good, I love coughing all night.", "negative", "sarcasm"),
         ("The service is not never clean.", "negative", "double negative"),
         ("I cannot say it is not bad.", "negative", "double negative"),
         ("The bus is fast but the station is dirty and the staff rude.", "negative", "mixed"),
         ("Clean roads but terrible smoke.", "negative", "mixed"),
         ("The air is not good at all.", "negative", "negation"),
         ("The air is awful and toxic.", "negative", "unknown words")]
print("\n=== Sentiment scorer on adversarial sentences ===")
fails = 0
for t, truth, kind in tests:
    s = score(t); lab = "positive" if s > 0 else "negative" if s < 0 else "neutral"
    ok = lab == truth; fails += not ok
    print(f"{'ok  ' if ok else 'FAIL'} [{kind:14}] score={s:+d} got={lab:8} truth={truth:8} | {t}")
print(f"{fails} of {len(tests)} fail")

# ---------------- executemany vs execute loop ------------------------------
print("\n=== executemany vs execute() loop (file database, commit per call pattern) ===")
for n in (1_000, 20_000, 100_000):
    data = [(f"S{i%12}", "2026-10-01", float(i % 200)) for i in range(n)]
    out = []
    for mode in ("executemany", "execute loop (commit each 1)", "execute loop (one commit)"):
        if os.path.exists("t.db"): os.remove("t.db")
        c = sqlite3.connect("t.db"); c.execute("CREATE TABLE a (s TEXT, d TEXT, p REAL)")
        t0 = time.perf_counter()
        if mode == "executemany": c.executemany("INSERT INTO a VALUES (?,?,?)", data); c.commit()
        elif "each" in mode:
            for r in data[:min(n, 1000)]: c.execute("INSERT INTO a VALUES (?,?,?)", r); c.commit()
        else:
            for r in data: c.execute("INSERT INTO a VALUES (?,?,?)", r)
            c.commit()
        el = time.perf_counter() - t0
        if "each" in mode: el = el / min(n, 1000) * n
        out.append(f"{mode}: {el:.3f}s"); c.close()
    print(f"n={n:>7} | " + " | ".join(out))
os.remove("t.db")
