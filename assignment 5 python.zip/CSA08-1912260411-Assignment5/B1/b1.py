"""B1 - Implement and validate the cleaning pipeline (air-quality network)."""
import csv, io, sqlite3, time, tracemalloc, random
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

# ---------------- Complete the Code (TODO 1 and TODO 2) --------------------
RAW = """station,date,pm25
Adyar,2026-10-01,48
Adyar,2026-10-02,NA
Adyar,2026-10-03,
Guindy,2026-10-01,95
Guindy,2026-10-02,-5
Guindy,2026-10-03,121
Guindy,2026-10-04,1500
"""
MAX_PM25 = 999

def load_clean(text):
    """Returns (station, date, pm25) tuples for valid, non-negative readings only."""
    rows = []
    for r in csv.DictReader(io.StringIO(text)):               # TODO 1
        v = r["pm25"].strip()
        if v == "" or v.upper() == "NA":
            continue
        v = float(v)
        if v < 0 or v > MAX_PM25:                              # extra check: > 999
            continue
        rows.append((r["station"], r["date"], v))
    return rows

def min_max(values):
    lo, hi = min(values), max(values)                          # TODO 2
    return [round((v - lo) / (hi - lo), 3) for v in values]

print("=== Complete the Code ===")
clean = load_clean(RAW)
print(clean)
print(min_max([pm for _, _, pm in clean]))

# ---------------- B1.1 full pipeline on a small messy file -----------------
MESSY = """station,date,hour,pm25,pm10,no2,temp
 adyar ,2026-10-01,8,48,80,30,30.5
ADYAR,2026-10-01,9,NA,82,31,31.0
Adyar,2026-10-01,10,,85,29,31.5
Adyar,2026-10-01,11,60,90,33,32.0
Adyar,2026-10-01,11,60,90,33,32.0
Guindy,01/10/2026,8,95,150,45,89.6
Guindy,2026-10-01,9,-5,150,44,91.4
Guindy,2026-10-01,10,5000,160,46,93.2
Guindy,2026-10-01,11,121,170,50,95.0
"""
F_STATIONS = {"Guindy"}          # stations that report Fahrenheit

def clean_file(text, log):
    out, seen, last = [], set(), {}
    for r in csv.DictReader(io.StringIO(text)):
        st = r["station"].strip().title()
        d = r["date"].strip()
        if "/" in d:                                           # dd/mm/yyyy -> ISO
            dd, mm, yy = d.split("/"); d = f"{yy}-{mm}-{dd}"
        key = (st, d, r["hour"])
        if key in seen:
            log.append(f"duplicate dropped {key}"); continue
        seen.add(key)
        def num(x):
            x = x.strip()
            return None if x == "" or x.upper() == "NA" else float(x)
        pm25, pm10, no2, t = (num(r[k]) for k in ("pm25", "pm10", "no2", "temp"))
        if st in F_STATIONS and t is not None:
            t = round((t - 32) * 5 / 9, 1); log.append(f"{st} {d} h{r['hour']}: F -> C")
        if pm25 is not None and (pm25 < 0 or pm25 > MAX_PM25):
            log.append(f"{st} {d} h{r['hour']}: impossible pm25 {pm25} -> missing"); pm25 = None
        if pm25 is None:                                       # forward fill
            if st in last:
                pm25 = last[st]; log.append(f"{st} {d} h{r['hour']}: pm25 forward-filled {pm25}")
            else:
                log.append(f"{st} {d} h{r['hour']}: no previous value, row dropped"); continue
        last[st] = pm25
        out.append((st, d, int(r["hour"]), pm25, pm10, no2, t))
    return out

print("\n=== B1.1 Before cleaning ===")
print(MESSY)
log = []
cleaned = clean_file(MESSY, log)
print("=== After cleaning (station, date, hour, pm25, pm10, no2, temp_C) ===")
for r in cleaned: print(r)
print("\nCleaning log:")
for l in log: print(" ", l)
assert all(0 <= r[3] <= MAX_PM25 for r in cleaned)
assert len({(r[0], r[1], r[2]) for r in cleaned}) == len(cleaned)
print("assert checks passed: no impossible values, no duplicates")

# ---------------- B1.3 store and query -------------------------------------
# build a month of data for 3 stations so the questions are meaningful
random.seed(5)
rows = []
base = {"Adyar": 55, "Guindy": 90, "Velachery": 70}
for st, b in base.items():
    for day in range(1, 31):
        for hr in range(0, 24, 3):
            pm = max(5, random.gauss(b + (15 if 7 <= hr <= 10 or 18 <= hr <= 21 else 0), 12))
            temp = 22 + 8 * random.random() + (6 if 11 <= hr <= 16 else 0)
            rows.append((st, f"2026-10-{day:02d}", hr, round(pm, 1), round(pm * 1.6, 1), round(20 + random.random() * 30, 1), round(temp, 1)))
con = sqlite3.connect("airquality.db")
con.execute("DROP TABLE IF EXISTS readings"); con.execute("DROP TABLE IF EXISTS stations")
con.execute("CREATE TABLE stations (station_id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, temp_unit TEXT)")
con.execute("""CREATE TABLE readings (station_id INTEGER NOT NULL REFERENCES stations(station_id),
 day TEXT NOT NULL, hour INTEGER NOT NULL, pm25 REAL, pm10 REAL, no2 REAL, temp_c REAL,
 PRIMARY KEY (station_id, day, hour))""")
con.executemany("INSERT INTO stations(name,temp_unit) VALUES (?,?)", [("Adyar", "C"), ("Guindy", "F"), ("Velachery", "C")])
ids = dict(con.execute("SELECT name, station_id FROM stations"))
con.executemany("INSERT INTO readings VALUES (?,?,?,?,?,?,?)", [(ids[r[0]],) + r[1:] for r in rows])
con.commit()
print(f"\n=== B1.3 Loaded {len(rows)} readings with executemany ===")
q1 = con.execute("SELECT ROUND(AVG(pm25),2) FROM readings r JOIN stations s USING(station_id) WHERE s.name=? AND day LIKE '2026-10-%'", ("Adyar",)).fetchone()[0]
print("Q1 average PM2.5 of Adyar in October:", q1)
print("Q2 stations ranked by mean PM2.5:")
for r in con.execute("SELECT s.name, ROUND(AVG(pm25),2) FROM readings r JOIN stations s USING(station_id) GROUP BY s.name ORDER BY 2 DESC"): print("  ", r)
print("Q3 five worst hours of the day (all stations):")
worst = con.execute("SELECT hour, ROUND(AVG(pm25),2) FROM readings GROUP BY hour ORDER BY 2 DESC").fetchall()
for r in worst[:5]: print("  ", r)

# ---------------- B1.4 charts ----------------------------------------------
df = pd.read_sql("SELECT s.name, day, hour, pm25, temp_c FROM readings r JOIN stations s USING(station_id)", con)
fig, ax = plt.subplots(2, 2, figsize=(11, 8))
for st, g in df.groupby("name"):
    d = g.groupby("day").pm25.mean(); ax[0, 0].plot(range(1, len(d) + 1), d.values, label=st)
ax[0, 0].set(title="Daily mean PM2.5 - October 2026", xlabel="Day of month", ylabel="PM2.5 (ug/m3)"); ax[0, 0].legend()
m = df.groupby("name").pm25.mean(); ax[0, 1].bar(m.index, m.values, color=["tab:blue", "tab:red", "tab:green"])
ax[0, 1].set(title="Mean PM2.5 by station", xlabel="Station", ylabel="PM2.5 (ug/m3)")
ax[1, 0].scatter(df.temp_c, df.pm25, s=6, alpha=.5); ax[1, 0].set(title="Temperature vs PM2.5", xlabel="Temperature (C)", ylabel="PM2.5 (ug/m3)")
h = df.groupby("hour").pm25.mean(); ax[1, 1].bar(h.index, h.values, width=2); ax[1, 1].set(title="Mean PM2.5 by hour of day", xlabel="Hour", ylabel="PM2.5 (ug/m3)")
plt.tight_layout(); plt.savefig("charts.png", dpi=110)
print("\nCharts saved to charts.png")
print("Correlation temp vs PM2.5: %.3f" % df.temp_c.corr(df.pm25))
print("Rush-hour (7-10, 18-21) mean %.1f vs other hours %.1f" % (df[df.hour.isin([9,18,21])].pm25.mean(), df[~df.hour.isin([9,18,21])].pm25.mean()))
con.close()

# ---------------- Alternative: csv+loops vs pandas -------------------------
def gen(n):
    random.seed(1); lines = ["station,date,pm25"]
    for i in range(n):
        v = random.choice(["NA", "", "-3", "1500"]) if random.random() < .08 else f"{random.uniform(10,200):.1f}"
        lines.append(f"S{i%12},2026-10-{i%30+1:02d},{v}")
    return "\n".join(lines) + "\n"

def pandas_clean(text):
    d = pd.read_csv(io.StringIO(text), na_values=["NA", ""])
    d = d.dropna(subset=["pm25"]); d = d[(d.pm25 >= 0) & (d.pm25 <= MAX_PM25)]
    d["norm"] = (d.pm25 - d.pm25.min()) / (d.pm25.max() - d.pm25.min()); return d

print("\n=== csv-loop vs pandas (time s / peak memory MB) ===")
print(f"{'rows':>9} | {'loop s':>7} {'loop MB':>8} | {'pandas s':>8} {'pandas MB':>9}")
for n in (1_000, 100_000, 1_000_000):
    t = gen(n)
    tracemalloc.start(); s = time.perf_counter(); r = load_clean(t); min_max([x[2] for x in r]); a = time.perf_counter() - s
    ma = tracemalloc.get_traced_memory()[1] / 1e6; tracemalloc.stop()
    tracemalloc.start(); s = time.perf_counter(); pandas_clean(t); b = time.perf_counter() - s
    mb = tracemalloc.get_traced_memory()[1] / 1e6; tracemalloc.stop()
    print(f"{n:>9} | {a:7.3f} {ma:8.1f} | {b:8.3f} {mb:9.1f}")
