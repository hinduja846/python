"""B4 - Final engineering decision: sentiment, summariser, index, production check."""
import math, random, re, sqlite3, time
from collections import Counter
from complaints import COMPLAINTS

# ---------------- Complete the Code ----------------------------------------
POSITIVE = {"good", "clean", "fast", "helpful", "improved"}
NEGATIVE = {"bad", "dirty", "slow", "rude", "smoke", "broken"}
NEGATORS = {"not", "never", "no"}

def score(text, pos=POSITIVE, neg=NEGATIVE):
    """+1 per positive word, -1 per negative word; a preceding negator flips it."""
    words = text.lower().replace(".", " ").replace(",", " ").split()
    total = 0
    for i, w in enumerate(words):                                   # TODO 1
        v = 1 if w in pos else -1 if w in neg else 0
        if v and i > 0 and words[i - 1] in NEGATORS:
            v = -v
        total += v
    return total

def label(text, **kw):
    s = score(text, **kw)
    return "positive" if s > 0 else "negative" if s < 0 else "neutral"

print("=== Complete the Code ===")
for c in ["Roads are clean and the bus was fast.", "Smoke from the factory, air is bad.",
          "The staff were not helpful.", "Not bad, service improved."]:
    print(f"{label(c):8} | {c}")

# ---------------- B4.1 on 50 complaints ------------------------------------
EXT_POS = POSITIVE | {"thank", "great", "fresh", "like", "clear", "quick", "safe", "fine"}
EXT_NEG = NEGATIVE | {"terrible", "wrong", "dangerous", "crashes", "leaking", "worried", "dust", "smell", "noise", "nothing", "dismissive", "never"}
def lab_ext(t): return label(t, pos=EXT_POS, neg=EXT_NEG - {"never"})

print("\n=== B4.1 Sentiment on 50 complaints: agreement with my own labels ===")
for name, f in (("given lexicon", label), ("extended lexicon", lab_ext)):
    hits = sum(f(t) == l for t, l, _ in COMPLAINTS)
    print(f"{name:17}: {hits}/50 agree ({hits*2}%)")
    by = Counter((l, f(t)) for t, l, _ in COMPLAINTS if f(t) != l)
    print("   disagreements (mine -> scorer):", dict(by))
print("\nWrongly labelled by the given lexicon (first 8):")
n = 0
for t, l, _ in COMPLAINTS:
    if label(t) != l and n < 8:
        print(f"  mine={l:8} scorer={label(t):8} score={score(t):+d} | {t}"); n += 1

# summariser: pick the sentence with the highest total frequency of important words
STOP = set("a an the is are was were am be been to of in on at for and or but it its this that these those i we you he she they my our your their me us with from by as so do does did have has had not no never can could would should will please also very just".split())
def sentences(t): return [s.strip() for s in re.split(r"(?<=[.!?])\s+", t) if s.strip()]
def words(s): return [w for w in re.findall(r"[a-z0-9']+", s.lower()) if w not in STOP]
FREQ = Counter(w for t, _, _ in COMPLAINTS for w in words(t))

def summarise(t):
    ss = sentences(t)
    return max(range(len(ss)), key=lambda i: (sum(FREQ[w] for w in words(ss[i])), -i))
def first_k(t): return 0

multi = [(t, k) for t, _, k in COMPLAINTS if len(sentences(t)) > 1]
a = sum(summarise(t) == k for t, k in multi); b = sum(first_k(t) == k for t, k in multi)
print(f"\n=== Summariser on the {len(multi)} multi-sentence complaints (picked sentence = my key sentence) ===")
print(f"frequency-based : {a}/{len(multi)} agree")
print(f"first sentence  : {b}/{len(multi)} agree")
print("Examples of summaries (frequency-based):")
for t, _, _ in COMPLAINTS[:3]:
    print("  ->", sentences(t)[summarise(t)])
print("Where frequency-based fails:")
c = 0
for t, k in multi:
    if summarise(t) != k and c < 3:
        print("  chose:", sentences(t)[summarise(t)], "| wanted:", sentences(t)[k]); c += 1

# naive Bayes, leave-one-out, to see what a trained model would do with only 50 examples
def nb_predict(train, text):
    labs = Counter(l for _, l, _ in train); vocab = set(w for t, _, _ in train for w in words(t))
    best, bl = None, None
    for l in labs:
        cnt = Counter(w for t, ll, _ in train if ll == l for w in words(t)); tot = sum(cnt.values())
        lp = math.log(labs[l] / len(train)) + sum(math.log((cnt[w] + 1) / (tot + len(vocab) + 1)) for w in words(text))
        if best is None or lp > best: best, bl = lp, l
    return bl
loo = sum(nb_predict(COMPLAINTS[:i] + COMPLAINTS[i+1:], COMPLAINTS[i][0]) == COMPLAINTS[i][1] for i in range(50))
print(f"\nNaive Bayes (word counts, leave-one-out on only 50 examples): {loo}/50 agree")
t0 = time.perf_counter()
for _ in range(2000): label(COMPLAINTS[0][0])
t1 = time.perf_counter()
print(f"time per complaint: lexicon {(t1-t0)/2000*1e6:.1f} us")
t0 = time.perf_counter()
for _ in range(200): nb_predict(COMPLAINTS, COMPLAINTS[0][0])
print(f"time per complaint: naive Bayes (recounting every call, no cached model) {(time.perf_counter()-t0)/200*1e6:.0f} us")

# ---------------- B4.2 index -----------------------------------------------
print("\n=== B4.2 Index on (station, day), 1,051,200 readings (120 stations x 8760) ===")
con = sqlite3.connect(":memory:")
con.execute("CREATE TABLE readings (station TEXT, day TEXT, hour INT, pm25 REAL)")
random.seed(3)
import datetime
d0 = datetime.date(2026, 1, 1)
days = [(d0 + datetime.timedelta(days=i)).isoformat() for i in range(365)]
con.executemany("INSERT INTO readings VALUES (?,?,?,?)",
                ((f"S{s:03d}", d, h, round(random.uniform(10, 150), 1)) for s in range(120) for d in days for h in range(24)))
con.commit()
Q = "SELECT AVG(pm25) FROM readings WHERE station = ? AND day BETWEEN ? AND ?"
args = ("S077", "2026-10-01", "2026-10-31")
def timeit_q(n=20):
    t0 = time.perf_counter()
    for _ in range(n): r = con.execute(Q, args).fetchone()
    return (time.perf_counter() - t0) / n * 1000, r[0]
print("plan before:", con.execute("EXPLAIN QUERY PLAN " + Q, args).fetchall()[0][-1])
t_before, v1 = timeit_q(5)
t0 = time.perf_counter(); con.execute("CREATE INDEX idx_station_day ON readings(station, day)"); build = time.perf_counter() - t0
print("plan after :", con.execute("EXPLAIN QUERY PLAN " + Q, args).fetchall()[0][-1])
t_after, v2 = timeit_q(200)
print(f"query time before index: {t_before:.2f} ms | after: {t_after:.3f} ms | speed-up x{t_before/t_after:.0f} | same answer: {v1 == v2}")
print(f"index build time: {build:.2f} s (paid once, plus a small cost on every insert)")
con.close()
