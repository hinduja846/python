#!/bin/bash
# Usage: ./push_to_github.sh https://github.com/<username>/CSA08-1912260411-Assignment5.git
set -e
git init -b main
for t in A1 A2 A3 A4 A5 B1 B2 B3 B4; do git add "$t"; git commit -m "Add $t"; done
git add README.md requirements.txt .gitignore push_to_github.sh
git commit -m "Add README and requirements"
git remote add origin "$1"
git push -u origin main
