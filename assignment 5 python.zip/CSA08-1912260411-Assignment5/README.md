# CSA08-1912260411-Assignment5

- **Name:** V. Hinduja
- **Register number:** 1912260411
- **Course / assignment:** CSA08 - Assignment 5 (CO5: data acquisition, cleaning, analysis and AI applications)
- **Python version:** 3.12
- **Libraries:** standard library (csv, sqlite3, statistics, re, cProfile, timeit); pandas 3.0.6; matplotlib 3.11.2 (see requirements.txt)
- **GitHub link:** *(paste your repository link here and on the report cover page)*
- **Data note:** all air-quality readings and station names are simulated by the programs; the 50 complaints in B4/complaints.py were written for this assignment.

| Folder | Task | Run command | Result |
|---|---|---|---|
| A1 | Data acquisition design | (answer.txt only) | 9 expected data problems; 2-table SQLite design; CSV vs SQL (full scan vs index) |
| A2 | Cleaning and normalisation design | (answer.txt only) | 4 cleaning rules, min-max and z-score, standard formats |
| A3 | Analysis and visualisation design | (answer.txt only) | line, bar, scatter, hour bars; daily summary GROUP BY |
| A4 | Debugging and profiling plan | `python measure_logging.py` | disabled log call 0.087 us vs print 0.79 us vs file log 5.7 us |
| A5 | AI application design | (answer.txt only) | lexicon scorer, extractive summariser, rule chatbot and limits |
| B1 | Cleaning pipeline | `python b1.py` | expected output reproduced; pandas 17x faster than loops at 1M rows |
| B2 | Adversarial data | `python b2.py` | expected output reproduced; placeholder stops injection; 5 of 8 hard sentences fail |
| B3 | Loops vs pandas vs SQL | `python b3.py` | all methods agree; at 1M rows pandas 0.52 s, loops 1.97 s, SQL 1.87 s |
| B4 | Final decision | `python b4.py` | expected output reproduced; sentiment 44/50 agree; index 28.8 ms -> 0.054 ms |

Commit progressively: at least one commit for each task folder (see push_to_github.sh).
