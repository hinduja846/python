"""A4 evidence: cost of print vs logging calls (100,000 calls each)."""
import io, logging, sys, time
N = 100_000
def t(f):
    s = time.perf_counter(); f(); return time.perf_counter() - s
buf = io.StringIO(); old = sys.stdout
def prints():
    sys.stdout = buf
    for i in range(N): print("row", i, 48.0)
    sys.stdout = old
log = logging.getLogger("aq"); log.propagate = False
fh = logging.FileHandler("tmp.log", mode="w"); log.addHandler(fh)
def log_on():
    log.setLevel(logging.INFO)
    for i in range(N): log.info("row %s %s", i, 48.0)
def log_off():
    log.setLevel(logging.WARNING)
    for i in range(N): log.info("row %s %s", i, 48.0)
a, b, c = t(prints), t(log_on), t(log_off)
print(f"print to memory buffer : {a:.3f} s for {N} calls ({a/N*1e6:.2f} us each)")
print(f"logging INFO to file   : {b:.3f} s ({b/N*1e6:.2f} us each)")
print(f"logging switched off   : {c:.3f} s ({c/N*1e6:.3f} us each)")
import os; os.remove("tmp.log")
