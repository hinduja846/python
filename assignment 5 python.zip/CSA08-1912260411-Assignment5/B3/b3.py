"""B3 - Loops vs libraries vs SQL: daily mean PM2.5 per station."""
import csv, io, random, sqlite3, statistics, time, cProfile, pstats, tracemalloc
from collections import defaultdict
import pandas as pd

def generate(stations, seed=7):
    """One year, hourly: 8,760 readings per station, ~3% blank/NA."""
    random.seed(seed)
    out = io.StringIO(); w = csv.writer(out); w.writerow(["station", "date", "hour", "pm25"])
    import datetime
    d0 = datetime.date(2026, 1, 1)
    for s in range(stations):
        base = random.uniform(40, 110)
        for day in range(365):
            d = (d0 + datetime.timedelta(days=day)).isoformat()
            for h in range(24):
                v = "" if random.random() < .03 else round(max(2, random.gauss(base, 20)), 1)
                w.writerow([f"S{s:03d}", d, h, v])
    return out.getvalue()

def by_loops(text):
    groups = defaultdict(list)
    for r in csv.DictReader(io.StringIO(text)):
        if r["pm25"] != "":
            groups[(r["station"], r["date"])].append(float(r["pm25"]))
    return {k: statistics.mean(v) for k, v in groups.items()}

def by_running_sum(text):                         # alternative: one pass, sum+count only
    acc = {}
    for r in csv.DictReader(io.StringIO(text)):
        if r["pm25"] != "":
            k = (r["station"], r["date"]); s, c = acc.get(k, (0.0, 0))
            acc[k] = (s + float(r["pm25"]), c + 1)
    return {k: s / c for k, (s, c) in acc.items()}

def by_pandas(text):
    df = pd.read_csv(io.StringIO(text))
    g = df.groupby(["station", "date"]).pm25.mean()
    return {k: v for k, v in g.items()}

def by_sql(text):
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE r (station TEXT, date TEXT, hour INT, pm25 REAL)")
    rd = csv.reader(io.StringIO(text)); next(rd)
    con.executemany("INSERT INTO r VALUES (?,?,?,?)", ((a, b, int(c), float(d) if d != "" else None) for a, b, c, d in rd))
    res = {(s, d): m for s, d, m in con.execute("SELECT station, date, AVG(pm25) FROM r GROUP BY station, date")}
    con.close(); return res

# ---- B3.1 correctness on small data
small = "station,date,hour,pm25\nA,2026-10-01,0,40\nA,2026-10-01,1,60\nA,2026-10-01,2,\nA,2026-10-02,0,30\nB,2026-10-01,0,100\nB,2026-10-01,1,NA\n"
small = small.replace("NA", "")
a, b, c, d = by_loops(small), by_pandas(small), by_sql(small), by_running_sum(small)
print("=== B3.1 Correctness on small data ===")
for k in sorted(a): print(k, round(a[k], 3), round(b[k], 3), round(c[k], 3), round(d[k], 3))
agree = lambda x, y: x.keys() == y.keys() and all(abs(x[k] - y[k]) < 1e-9 for k in x)
print("loops == pandas:", agree(a, b), "| loops == SQL:", agree(a, c), "| loops == running-sum:", agree(a, d))

# ---- B3.2 timing at three sizes
print("\n=== B3.2 Time (s) and peak memory (MB) ===")
print(f"{'stations':>8} {'rows':>9} | {'loops':>7} {'run-sum':>8} {'pandas':>7} {'SQL':>7} | peak MB loops / run-sum / pandas")
texts = {}
for n in (1, 12, 120):
    t = generate(n); texts[n] = t; rows = n * 8760
    times, mems = [], []
    for f in (by_loops, by_running_sum, by_pandas, by_sql):
        s0 = time.perf_counter(); f(t); times.append(time.perf_counter() - s0)      # timed without tracemalloc
        tracemalloc.start(); f(t); mems.append(tracemalloc.get_traced_memory()[1] / 1e6); tracemalloc.stop()
    print(f"{n:>8} {rows:>9} | {times[0]:7.3f} {times[1]:8.3f} {times[2]:7.3f} {times[3]:7.3f} | {mems[0]:.1f} / {mems[1]:.1f} / {mems[2]:.1f}")
x, y = by_loops(texts[12]), by_pandas(texts[12]); z = by_sql(texts[12])
print("agreement at 12 stations: loops=pandas", agree(x, y), "loops=SQL", agree(x, z))

# ---- B3.3 profile
print("\n=== B3.3 cProfile of the plain-Python version (120 stations) ===")
pr = cProfile.Profile(); pr.enable(); by_loops(texts[120]); pr.disable()
st = pstats.Stats(pr); st.sort_stats("tottime").print_stats(6)

# ---- B3.4 stats.mean vs fsum cost
print("=== statistics.mean cost ===")
vals = [random.random() for _ in range(24)]
import timeit
print("statistics.mean(24 values):", round(timeit.timeit(lambda: statistics.mean(vals), number=20000) / 20000 * 1e6, 2), "us per call")
print("sum(v)/len(v):             ", round(timeit.timeit(lambda: sum(vals) / len(vals), number=20000) / 20000 * 1e6, 2), "us per call")
