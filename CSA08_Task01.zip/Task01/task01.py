"""Q1 - State Electricity Subsidy Eligibility (if / elif / else)."""
import timeit
from bisect import bisect_left

# ---------- 1. Buggy rule: separate if statements --------------------------
def decide_buggy(units, ration, senior):
    """Developer's version - every if is tested independently."""
    result = []
    if units <= 100:
        result.append("FULL")
    if units <= 200 and ration:          # forgot the lower bound 101
        result.append("PARTIAL")
    if senior:                           # forgot the condition units > 200
        result.append("ELDER")
    return result or ["NONE"]

# ---------- 2. Correct rule: if-elif-else (exactly one result) -------------
def decide_elif(units, ration, senior):
    if units <= 100:
        return "FULL"
    elif 101 <= units <= 200 and ration:
        return "PARTIAL"
    elif units > 200 and senior:
        return "ELDER"
    else:
        return "NONE"

# ---------- 3. Design decision: nested if vs combined Boolean --------------
def decide_nested(units, ration, senior):
    if units <= 100:
        return "FULL"
    else:
        if units <= 200:
            if ration:
                return "PARTIAL"
            return "NONE"
        else:
            if senior:
                return "ELDER"
            return "NONE"

def decide_bool(units, ration, senior):
    if units <= 100:
        return "FULL"
    if 101 <= units <= 200 and ration:
        return "PARTIAL"
    if units > 200 and senior:
        return "ELDER"
    return "NONE"

# ---------- 4. Alternatives -------------------------------------------------
def decide_match(units, ration, senior):          # Python 3.10+
    match units:
        case u if u <= 100:
            return "FULL"
        case u if u <= 200:
            return "PARTIAL" if ration else "NONE"
        case _:
            return "ELDER" if senior else "NONE"

SLABS = [                                          # (upper limit, rule)
    (100,           lambda r, s: "FULL"),
    (200,           lambda r, s: "PARTIAL" if r else "NONE"),
    (float("inf"),  lambda r, s: "ELDER" if s else "NONE"),
]

def decide_table(units, ration, senior):
    for upper, rule in SLABS:                      # O(k) scan
        if units <= upper:
            return rule(ration, senior)

# ---------- 5. Predictions (written BEFORE running) ------------------------
# (units, has ration card, has member > 80, predicted decision)
HOUSEHOLDS = [
    (50,  False, False, "FULL"),
    (100, False, False, "FULL"),      # boundary
    (101, True,  False, "PARTIAL"),   # boundary
    (101, False, False, "NONE"),
    (200, True,  False, "PARTIAL"),   # boundary
    (200, False, True,  "NONE"),      # 80+ member does not matter up to 200
    (201, False, True,  "ELDER"),     # boundary
    (201, True,  False, "NONE"),      # ration card does not matter above 200
]

if __name__ == "__main__":
    print("Q1 - predictions vs observed (units, ration, 80+ member)")
    print(f"{'household':24}{'predicted':10}{'if-elif':9}{'nested':9}{'bool':9}{'match':9}{'table':9}{'separate ifs'}")
    all_ok = True
    for u, r, s, pred in HOUSEHOLDS:
        outs = [f(u, r, s) for f in (decide_elif, decide_nested, decide_bool,
                                     decide_match, decide_table)]
        ok = all(o == pred for o in outs)
        all_ok &= ok
        print(f"{(u, r, s)!s:24}{pred:10}{outs[0]:9}{outs[1]:9}{outs[2]:9}"
              f"{outs[3]:9}{outs[4]:9}{decide_buggy(u, r, s)}   {'OK' if ok else 'MISMATCH'}")
    print("All predictions correct:", all_ok)

    # Exhaustive agreement check over a grid (including every boundary)
    funcs = (decide_nested, decide_bool, decide_match, decide_table)
    checked = disagree = double = 0
    for u in range(0, 401):
        for r in (False, True):
            for s in (False, True):
                checked += 1
                ref = decide_elif(u, r, s)
                disagree += any(f(u, r, s) != ref for f in funcs)
                double += len(decide_buggy(u, r, s)) > 1
    print(f"\nChecked {checked} households: implementations disagree = {disagree}; "
          f"households given 2+ subsidies by separate ifs = {double}")

    # Time per decision for k slabs (worst case = last slab)
    print("\nTime per decision, worst case (microseconds) - slab lookup by linear scan vs bisect")
    print(f"{'k slabs':>8} {'linear scan':>12} {'bisect':>8}")
    for k in (3, 30, 300, 3000):
        limits = [100 * (i + 1) for i in range(k - 1)] + [float("inf")]
        table = [(lim, (lambda r, s: "X")) for lim in limits]
        probe = 100 * k          # lands in the last slab
        def scan():
            for upper, rule in table:
                if probe <= upper:
                    return rule(False, False)
        def bis():
            return table[bisect_left(limits, probe)][1](False, False)
        n = 20000
        t1 = timeit.timeit(scan, number=n) / n * 1e6
        t2 = timeit.timeit(bis, number=n) / n * 1e6
        print(f"{k:8} {t1:12.3f} {t2:8.3f}")
