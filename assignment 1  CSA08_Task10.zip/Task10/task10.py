from decimal import Decimal
from time import perf_counter

def measure(n):
    amounts = ["33.40"] * n
    t0 = perf_counter()
    total_f = 0.0
    for x in amounts:
        total_f += float(x)
    float_time = perf_counter() - t0

    t0 = perf_counter()
    total_d = Decimal("0.00")
    for x in amounts:
        total_d += Decimal(x)
    decimal_time = perf_counter() - t0
    print(f"n={n:6} float={total_f:.10f} Decimal={total_d} "
          f"float_time={float_time:.6f}s Decimal_time={decimal_time:.6f}s "
          f"difference={Decimal(str(total_f))-total_d}")

if __name__ == "__main__":
    for size in (300, 6000, 150000):
        measure(size)
