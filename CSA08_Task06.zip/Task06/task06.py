"""Q6 - Recursion and its limits: climbing n temple steps (1 or 2 at a time)."""
import sys
import time
from functools import lru_cache

calls = 0


def ways_naive(n):
    """Ways to climb n temple steps taking 1 or 2 steps at a time."""
    global calls
    calls += 1
    if n <= 1:
        return 1
    return ways_naive(n - 1) + ways_naive(n - 2)


@lru_cache(maxsize=None)
def ways_memo(n):
    global calls
    calls += 1
    # TODO 1 completed
    if n <= 1:
        return 1
    return ways_memo(n - 1) + ways_memo(n - 2)


def ways_loop(n):
    """Keeps only the last two values."""
    prev, cur = 1, 1                 # ways(0), ways(1)
    for _ in range(2, n + 1):
        prev, cur = cur, prev + cur
    return cur


def call_tree(n, depth=0, out=None):
    out = [] if out is None else out
    out.append("    " * depth + f"ways({n})")
    if n > 1:
        call_tree(n - 1, depth + 1, out)
        call_tree(n - 2, depth + 1, out)
    return out


if __name__ == "__main__":
    calls = 0; print("naive:", ways_naive(25), "calls =", calls)
    ways_memo.cache_clear()
    calls = 0; print("memo :", ways_memo(25), "calls =", calls)

    print("\nCorrectness check n = 1..6 (hand values: 1, 2, 3, 5, 8, 13)")
    hand = {1: 1, 2: 2, 3: 3, 4: 5, 5: 8, 6: 13}
    for n, h in hand.items():
        print(f"  n={n}: hand={h:3} naive={ways_naive(n):3} memo={ways_memo(n):3} loop={ways_loop(n):3}",
              "OK" if h == ways_naive(n) == ways_memo(n) == ways_loop(n) else "MISMATCH")

    print("\nCall tree for n = 5 (", len(call_tree(5)), "calls )")
    print("\n".join(call_tree(5)))

    print("\nGrowth investigation - number of calls")
    print(f"  {'n':>3} {'predicted 2*ways(n)-1':>22} {'naive calls':>12} {'memo calls':>11} {'loop iterations':>16}")
    for n in (10, 20, 25, 30):
        calls = 0; ways_naive(n); nc = calls
        ways_memo.cache_clear(); calls = 0; ways_memo(n); mc = calls
        print(f"  {n:3} {2 * ways_loop(n) - 1:22} {nc:12} {mc:11} {max(n - 1, 0):16}")

    print("\nDeployment: n = 1000")
    print("  sys.getrecursionlimit() =", sys.getrecursionlimit())
    ways_memo.cache_clear()
    try:
        ways_memo(1000)
        print("  memo(1000) worked with the default limit")
    except RecursionError as e:
        print("  memo(1000) -> RecursionError:", e)

    ways_memo.cache_clear()
    sys.setrecursionlimit(5000)
    t = time.perf_counter(); v1 = ways_memo(1000); t1 = time.perf_counter() - t
    print(f"  memo(1000) with limit 5000 -> {len(str(v1))} digits, {t1 * 1000:.3f} ms")
    sys.setrecursionlimit(1000)

    ways_memo.cache_clear()
    t = time.perf_counter()
    for k in range(0, 1001, 100):    # warm the cache in small steps: depth never above ~100
        ways_memo(k)
    v2 = ways_memo(1000); t2 = time.perf_counter() - t
    print(f"  memo(1000) warmed in steps of 100 with default limit -> same value: {v2 == v1}, {t2 * 1000:.3f} ms")

    t = time.perf_counter(); v3 = ways_loop(1000); t3 = time.perf_counter() - t
    print(f"  loop(1000) -> same value: {v3 == v1}, {t3 * 1000:.3f} ms, no recursion")

    phi_calls = 2 * v3 - 1
    print(f"  naive(1000) would need 2*ways(1000)-1 = a {len(str(phi_calls))}-digit number of calls (not run)")
