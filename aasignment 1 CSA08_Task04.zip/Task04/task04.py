import math
for expr in [(4.2-3.5)/0.1, 0.1+0.2, -7//2]:
    print(expr)
fat_values = (4.2, 3.1)
for fat in fat_values:
    steps = (fat-3.5)/0.1
    print(f"fat={fat}: raw={steps}, int={int(steps)}, floor={math.floor(steps)}, round={round(steps)}")
print("-2**2 =", -2**2, "and (-2)**2 =", (-2)**2)
