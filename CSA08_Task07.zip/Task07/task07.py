"""Q7 - Diagnose, Redesign and Validate.
Selected program: ways_naive (Q6) - plain recursion for counting temple-step climbs.
"""
import sys
import time
from functools import lru_cache

calls = 0


def ways_naive(n):                       # ORIGINAL (Q6)
    global calls
    calls += 1
    if n <= 1:
        return 1
    return ways_naive(n - 1) + ways_naive(n - 2)


@lru_cache(maxsize=None)
def ways_memo(n):                        # intermediate fix (Q6)
    global calls
    calls += 1
    if n <= 1:
        return 1
    return ways_memo(n - 1) + ways_memo(n - 2)


additions = 0


def ways_redesigned(n):
    """REDESIGN: bottom-up, keeps only the last two values (O(n) time, O(1) extra space)."""
    global additions
    prev, cur = 1, 1                     # ways(0), ways(1)
    for _ in range(2, n + 1):
        prev, cur = cur, prev + cur
        additions += 1
    return cur


def ways_table(n):
    """Redesign variant for the trust's printout: every value 0..n in one pass, O(n) space."""
    table = [1, 1]
    for i in range(2, n + 1):
        table.append(table[-1] + table[-2])
    return table[: n + 1]


def best_time(fn, arg, repeats=5):
    best = float("inf")
    for _ in range(repeats):
        t = time.perf_counter(); fn(arg); best = min(best, time.perf_counter() - t)
    return best


if __name__ == "__main__":
    print("A. DIAGNOSIS (evidence from Q6): naive recursion")
    print(f"  {'n':>3} {'calls':>10} {'calls / calls 5 steps earlier':>30} {'distinct n values':>18} {'repeated calls':>15}")
    prev = None
    for n in (10, 15, 20, 25, 30):
        calls = 0; ways_naive(n); c = calls
        ratio = f"{c / prev:.3f}" if prev else "-"
        prev = c
        print(f"  {n:3} {c:10} {ratio:>30} {n + 1:18} {c - (n + 1):15}")
    print("  (golden ratio 1.618 per step -> 1.618^5 = 11.09 per 5 steps: the growth is exponential)")
    print("  calls(n)/calls(n-1) for single steps:",
          " ".join(f"{(lambda a, b: a / b)(2*ways_redesigned(n)-1, 2*ways_redesigned(n-1)-1):.4f}" for n in (10, 20, 30)))

    print("\nD. PREDICTION (made before the experiment)")
    print("  calls(n) = 2*ways(n) - 1 : n=30 -> 2,692,537 ; redesigned: n-1 additions, no calls")
    print("  Expected: n=30 redesigned is >100,000x fewer operations and >1000x faster;")
    print("            n=1000 runs with no RecursionError in well under 1 ms.")

    print("\nE. ORIGINAL vs MEMO vs REDESIGN, same inputs")
    print(f"  {'n':>3} {'naive calls':>12} {'memo calls':>11} {'redesign adds':>14} {'naive s':>10} {'memo s':>10} {'redesign s':>11}")
    for n in (10, 20, 25, 30):
        calls = 0; ways_naive(n); nc = calls
        ways_memo.cache_clear(); calls = 0; ways_memo(n); mc = calls
        additions = 0; ways_redesigned(n); ra = additions
        tn = best_time(ways_naive, n, 3)
        def memo_cold(k):
            ways_memo.cache_clear(); ways_memo(k)
        tm = best_time(memo_cold, n)
        tr = best_time(ways_redesigned, n)
        assert ways_naive(n) == ways_memo(n) == ways_redesigned(n)
        print(f"  {n:3} {nc:12} {mc:11} {ra:14} {tn:10.6f} {tm:10.6f} {tr:11.7f}")

    print("\n  n = 1000")
    sys.setrecursionlimit(1000)
    ways_memo.cache_clear()
    try:
        ways_memo(1000); r = "OK"
    except RecursionError:
        r = "RecursionError (limit 1000)"
    additions = 0
    v = ways_redesigned(1000)
    adds_1000 = additions
    t = best_time(ways_redesigned, 1000)
    tab = ways_table(1000)
    t_tab = best_time(ways_table, 1000)
    print(f"  memo (default limit)  : {r}")
    print(f"  redesigned            : {len(str(v))}-digit answer, {adds_1000} additions, {t*1000:.3f} ms, no recursion")
    print(f"  table of all 0..1000  : {len(tab)} values, {t_tab*1000:.3f} ms; last == redesigned: {tab[-1] == v}")
    print(f"  naive would need      : 2*ways(1000)-1 calls, a {len(str(2*v-1))}-digit number (not executable)")

    # Memory check
    import tracemalloc
    tracemalloc.start(); ways_redesigned(1000); _, peak_loop = tracemalloc.get_traced_memory(); tracemalloc.stop()
    tracemalloc.start(); ways_table(1000); _, peak_tab = tracemalloc.get_traced_memory(); tracemalloc.stop()
    print(f"\n  peak extra memory n=1000: two-variable loop {peak_loop/1024:.1f} KiB, full table {peak_tab/1024:.1f} KiB")

    # Figures
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        ns = list(range(1, 31))
        naive_calls = []
        for n in ns:
            calls = 0; ways_naive(n); naive_calls.append(calls)
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.semilogy(ns, naive_calls, "o-", label="naive recursion (calls)")
        ax.semilogy(ns, [n + 1 for n in ns], "s-", label="memoised (calls) = n+1")
        ax.semilogy(ns, [max(n - 1, 0) or 1 for n in ns], "^-", label="redesigned loop (additions) = n-1")
        ax.set_xlabel("n (steps)"); ax.set_ylabel("operations (log scale)")
        ax.set_title("Q7: work vs n"); ax.legend(); ax.grid(True, which="both", alpha=.3)
        fig.tight_layout(); fig.savefig("graph_calls.png", dpi=130); plt.close(fig)

        fig, ax = plt.subplots(figsize=(4.2, 7))
        ax.axis("off"); ax.set_xlim(0, 10); ax.set_ylim(0, 14)
        def box(y, text, shape="round"):
            ax.text(5, y, text, ha="center", va="center", fontsize=9,
                    bbox=dict(boxstyle="round,pad=0.4" if shape == "round" else "square,pad=0.4",
                              fc="#e8f0fe" if shape == "round" else "#fff3cd", ec="black"))
        def arrow(y1, y2, label=""):
            ax.annotate("", xy=(5, y2), xytext=(5, y1), arrowprops=dict(arrowstyle="->"))
            if label: ax.text(5.2, (y1 + y2) / 2, label, fontsize=8)
        box(13, "START: read n"); arrow(12.4, 11.4)
        box(10.8, "prev = 1, cur = 1"); arrow(10.2, 9.2)
        box(8.6, "i = 2", ); arrow(8.0, 7.0)
        box(6.4, "i <= n ?", shape="sq"); arrow(5.8, 4.6, "yes")
        box(4.0, "prev, cur = cur, prev + cur"); arrow(3.4, 2.6)
        box(2.0, "i = i + 1")
        ax.plot([4.0, 1.2, 1.2], [2.0, 2.0, 6.4], "k-", lw=1)           # loop back
        ax.annotate("", xy=(3.9, 6.4), xytext=(1.2, 6.4), arrowprops=dict(arrowstyle="->"))
        ax.annotate("", xy=(8.4, 6.4), xytext=(6.1, 6.4), arrowprops=dict(arrowstyle="->"))
        ax.text(7.2, 6.65, "no", fontsize=8, ha="center")
        ax.text(9.3, 6.4, "OUTPUT\ncur\nEND", fontsize=8, va="center", ha="center",
                bbox=dict(boxstyle="round", fc="#d4edda", ec="black"))
        fig.savefig("flowchart.png", dpi=130, bbox_inches="tight"); plt.close(fig)
        print("\n  saved graph_calls.png and flowchart.png")
    except ImportError:
        print("\n  matplotlib not installed - figures skipped")
