"""Q2 - OTP verification: while, for, break, continue, pass, loop-else, recursion."""
OTP = "4821"

class Customer:
    """Feeds typed entries one by one (simulates the kiosk keypad)."""
    def __init__(self, entries, security_ok=False):
        self.it = iter(entries)
        self.security_ok = security_ok
    def read(self):
        return next(self.it, None)          # None -> customer walked away

# ---- Version 1: while loop ---------------------------------------------------
def otp_while(c, limit=3):
    attempts = 0
    while attempts < limit:
        entry = c.read()
        if entry is None:
            return "ABANDONED", attempts
        entry = entry.strip()
        if entry == "":
            continue                        # blank: NOT an attempt
        attempts += 1                       # counted only after a real entry
        if entry == OTP:
            break                           # success -> skip the else
        elif not entry.isdigit():
            pass                            # malformed but still counted; nothing extra to do
    else:
        return "LOCKED 30 min", attempts    # loop ended without break
    return "VERIFIED", attempts

# ---- Version 2: for + range(3) -----------------------------------------------
def read_nonblank(c):
    while True:
        entry = c.read()
        if entry is None:
            return None
        if entry.strip() == "":
            continue
        return entry.strip()

def otp_for(c):
    for attempt in range(1, 4):
        entry = read_nonblank(c)
        if entry is None:
            return "ABANDONED", attempt - 1
        if entry == OTP:
            break
        elif not entry.isdigit():
            pass
    else:
        return "LOCKED 30 min", 3
    return "VERIFIED", attempt

# ---- Buggy while: counter updated in the wrong place -------------------------
def otp_while_buggy(c, limit=3):
    attempts = 0
    while attempts < limit:
        entry = c.read()
        if entry is None:
            return "ABANDONED", attempts
        attempts += 1                       # BUG: before the blank check
        if entry.strip() == "":
            continue
        if entry.strip() == OTP:
            return "VERIFIED", attempts
    return "LOCKED 30 min", attempts

# ---- Changed condition: security question gives 2 extra attempts ---------------
def otp_with_security(c):
    limit, extended, attempts = 3, False, 0
    while True:
        while attempts < limit:
            entry = c.read()
            if entry is None:
                return "ABANDONED", attempts
            entry = entry.strip()
            if entry == "":
                continue
            attempts += 1
            if entry == OTP:
                return "VERIFIED", attempts
        if not extended and c.security_ok:   # offer extension only once
            limit, extended = 5, True
            continue
        return "LOCKED 30 min", attempts

# ---- Alternative: recursion --------------------------------------------------
max_depth = 0
def otp_recursive(c, attempt=1, limit=3, depth=1):
    global max_depth
    max_depth = max(max_depth, depth)
    if attempt > limit:
        return "LOCKED 30 min", limit
    entry = c.read()
    if entry is None:
        return "ABANDONED", attempt - 1
    entry = entry.strip()
    if entry == "":
        return otp_recursive(c, attempt, limit, depth + 1)   # blank: same attempt number
    if entry == OTP:
        return "VERIFIED", attempt
    return otp_recursive(c, attempt + 1, limit, depth + 1)

SCENARIOS = {
    "A blank, 2 wrong, correct": (["", "1111", "2222", "4821"], False),
    "B three wrong":            (["1111", "2222", "3333"], False),
    "C three wrong + sec. ok":  (["1111", "2222", "3333", "4444", "4821"], True),
    "D three wrong + sec. bad": (["1111", "2222", "3333", "4821"], False),
    "E blanks only then leaves": (["", " ", ""], False),
    "F non-digit, blank, wrong, ok": (["ab12", "", "0000", "4821"], False),
}

if __name__ == "__main__":
    print(f"{'scenario':32}{'while':26}{'for range(3)':26}{'recursive':26}")
    for name, (entries, sec) in SCENARIOS.items():
        global_depth = 0
        w = otp_while(Customer(entries))
        f = otp_for(Customer(entries))
        max_depth = 0
        r = otp_recursive(Customer(entries))
        print(f"{name:32}{w!s:26}{f!s:26}{r!s:26}")
    print("\nWrong counter placement (scenario A):")
    print("  correct while :", otp_while(Customer(SCENARIOS['A blank, 2 wrong, correct'][0])))
    print("  buggy   while :", otp_while_buggy(Customer(SCENARIOS['A blank, 2 wrong, correct'][0])))
    print("\nChanged condition (security question):")
    for key in ("C three wrong + sec. ok", "D three wrong + sec. bad", "B three wrong"):
        entries, sec = SCENARIOS[key]
        print(f"  {key:28}", otp_with_security(Customer(entries, security_ok=sec)))
    print("\nStack depth of recursive version (blank entries add frames):")
    for n_blank in (0, 5, 500):
        max_depth = 0
        otp_recursive(Customer([""] * n_blank + ["1111", "2222", "3333"]))
        print(f"  {n_blank:4} blank entries -> max depth {max_depth}")
