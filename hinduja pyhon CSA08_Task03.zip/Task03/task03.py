from decimal import Decimal
BASE_RATE = Decimal("30.00")
FAT_STEP_VALUE = Decimal("0.40")
SNF_STEP_VALUE = Decimal("0.30")
STANDARD_FAT = Decimal("3.5")
STANDARD_SNF = Decimal("8.5")
fat, snf = Decimal("4.2"), Decimal("8.7")
print("Rate constants:", BASE_RATE, FAT_STEP_VALUE, SNF_STEP_VALUE)
a, b = 10, 20
a, b = b, a
print("Swapped:", a, b)
value = 10
value = "ten"
print("Dynamic type:", value, type(value).__name__)
