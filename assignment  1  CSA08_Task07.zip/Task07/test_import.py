"""Demonstrate importing the milk-rate module."""
import milkrate as mr
from decimal import Decimal

if __name__ == "__main__":
    print("Imported payout:", mr.payout(Decimal("8.5"), Decimal("4.2"), Decimal("8.7")))
