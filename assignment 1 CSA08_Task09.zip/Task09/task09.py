"""Milk co-operative payment calculator using exact Decimal arithmetic."""
from decimal import Decimal, ROUND_HALF_UP

CENT = Decimal("0.01")
BASE_RATE = Decimal("30.00")
STANDARD_FAT = Decimal("3.5")
STANDARD_SNF = Decimal("8.5")
FAT_STEP = Decimal("0.1")
SNF_STEP = Decimal("0.1")
FAT_STEP_VALUE = Decimal("0.40")
SNF_STEP_VALUE = Decimal("0.30")
MIN_FAT = Decimal("2.0")
MAX_FAT = Decimal("7.0")
# Assumption: SNF limits are 6.0% to 10.0%; confirm with faculty/co-operative.
MIN_SNF = Decimal("6.0")
MAX_SNF = Decimal("10.0")

def money(value):
    """Quantize currency to paisa using an explicit half-up rule."""
    return value.quantize(CENT, rounding=ROUND_HALF_UP)

def nearest_step(value, standard, step):
    """Count nearest whole 0.1 percentage-point steps."""
    return int(((value - standard) / step).quantize(
        Decimal("1"), rounding=ROUND_HALF_UP
    ))

def validate_entry(litres, fat, snf):
    """Return True when quantity and quality values are within limits."""
    return litres > 0 and MIN_FAT <= fat <= MAX_FAT and MIN_SNF <= snf <= MAX_SNF

def rate_per_litre(fat, snf):
    """Return milk rate per litre."""
    fs = nearest_step(fat, STANDARD_FAT, FAT_STEP)
    ss = nearest_step(snf, STANDARD_SNF, SNF_STEP)
    return money(BASE_RATE + Decimal(fs)*FAT_STEP_VALUE + Decimal(ss)*SNF_STEP_VALUE)

def payout(litres, fat, snf):
    """Return payment for one accepted milk entry."""
    return money(litres * rate_per_litre(fat, snf))

def ten_day_total(entries):
    """Return total, accepted count, rejected count and detail rows."""
    total = Decimal("0.00")
    accepted = rejected = 0
    details = []
    for farmer_id, litres, fat, snf, shift in entries:
        if not validate_entry(litres, fat, snf):
            rejected += 1
            continue
        rate = rate_per_litre(fat, snf)
        amount = money(litres * rate)
        total += amount
        accepted += 1
        details.append((farmer_id, shift, litres, fat, snf, rate, amount))
    return money(total), accepted, rejected, details

def run_tests():
    """Run core calculation and validation assertions."""
    assert rate_per_litre(Decimal("3.5"), Decimal("8.5")) == Decimal("30.00")
    assert payout(Decimal("8.5"), Decimal("4.2"), Decimal("8.7")) == Decimal("283.90")
    assert payout(Decimal("12"), Decimal("3.1"), Decimal("8.3")) == Decimal("333.60")
    assert validate_entry(Decimal("1"), Decimal("2.0"), Decimal("8.5"))
    assert validate_entry(Decimal("1"), Decimal("7.0"), Decimal("8.5"))
    assert not validate_entry(Decimal("0"), Decimal("3.5"), Decimal("8.5"))
    assert not validate_entry(Decimal("1"), Decimal("1.9"), Decimal("8.5"))
    assert not validate_entry(Decimal("1"), Decimal("7.1"), Decimal("8.5"))
    five = [
        ("F1",Decimal("10"),Decimal("3.5"),Decimal("8.5"),"M"),
        ("F1",Decimal("8.5"),Decimal("4.2"),Decimal("8.7"),"E"),
        ("F1",Decimal("12"),Decimal("3.1"),Decimal("8.3"),"M"),
        ("F1",Decimal("1"),Decimal("2.0"),Decimal("8.5"),"E"),
        ("F1",Decimal("1"),Decimal("7.0"),Decimal("8.5"),"M"),
    ]
    total, ok, bad, _ = ten_day_total(five)
    assert total == Decimal("985.50") and ok == 5 and bad == 0
    print("All 9 test groups passed. Five-entry total = Rs", total)

if __name__ == "__main__":
    run_tests()
